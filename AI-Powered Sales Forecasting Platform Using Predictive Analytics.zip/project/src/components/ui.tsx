import type { ReactNode } from 'react';

interface SectionProps {
  title: string;
  icon?: ReactNode;
  children: ReactNode;
  action?: ReactNode;
  className?: string;
}

export function Section({ title, icon, children, action, className = '' }: SectionProps) {
  return (
    <div className={`card ${className}`}>
      <div className="flex items-center justify-between px-5 py-4 border-b border-neutral-800">
        <div className="flex items-center gap-2.5">
          {icon && <span className="text-primary-400">{icon}</span>}
          <h3 className="text-sm font-semibold text-neutral-200">{title}</h3>
        </div>
        {action}
      </div>
      <div className="p-5">{children}</div>
    </div>
  );
}

interface BadgeProps {
  variant?: 'primary' | 'success' | 'warning' | 'error' | 'neutral' | 'accent';
  children: ReactNode;
}

export function Badge({ variant = 'neutral', children }: BadgeProps) {
  const variants: Record<string, string> = {
    primary: 'bg-primary-500/15 text-primary-300 border border-primary-500/20',
    success: 'bg-accent-500/15 text-accent-300 border border-accent-500/20',
    warning: 'bg-warning-500/15 text-warning-300 border border-warning-500/20',
    error: 'bg-error-500/15 text-error-300 border border-error-500/20',
    neutral: 'bg-neutral-700/40 text-neutral-300 border border-neutral-600/40',
    accent: 'bg-accent-500/15 text-accent-300 border border-accent-500/20',
  };
  return <span className={`badge ${variants[variant]}`}>{children}</span>;
}

export function StatusBadge({ status }: { status: string }) {
  const map: Record<string, 'primary' | 'success' | 'warning' | 'error' | 'neutral' | 'accent'> = {
    New: 'primary',
    Qualified: 'accent',
    Proposal: 'warning',
    Negotiation: 'warning',
    'Closed Won': 'success',
    'Closed Lost': 'error',
    Draft: 'neutral',
    Sent: 'primary',
    Opened: 'warning',
    Replied: 'success',
    Bounced: 'error',
    Synced: 'success',
    Pending: 'warning',
    Failed: 'error',
    High: 'error',
    Medium: 'warning',
    Low: 'neutral',
  };
  return <Badge variant={map[status] ?? 'neutral'}>{status}</Badge>;
}

export function LoadingSpinner({ label }: { label?: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-12">
      <div className="w-8 h-8 border-2 border-neutral-700 border-t-primary-500 rounded-full animate-spin" />
      {label && <p className="text-sm text-neutral-500 mt-3">{label}</p>}
    </div>
  );
}

export function EmptyState({ title, description, icon }: { title: string; description: string; icon?: ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center py-12 text-center">
      {icon && <div className="text-neutral-700 mb-3">{icon}</div>}
      <h4 className="text-sm font-medium text-neutral-300">{title}</h4>
      <p className="text-xs text-neutral-500 mt-1 max-w-xs">{description}</p>
    </div>
  );
}

export function ErrorState({ message }: { message: string }) {
  return (
    <div className="flex flex-col items-center justify-center py-8 text-center">
      <div className="w-10 h-10 rounded-full bg-error-500/10 flex items-center justify-center mb-2">
        <svg className="w-5 h-5 text-error-400" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth="2">
          <path strokeLinecap="round" strokeLinejoin="round" d="M12 9v2m0 4h.01M5.07 19h13.86c1.54 0 2.5-1.67 1.73-3L13.73 4c-.77-1.33-2.69-1.33-3.46 0L3.34 16c-.77 1.33.19 3 1.73 3z" />
        </svg>
      </div>
      <p className="text-sm text-error-300">{message}</p>
    </div>
  );
}
