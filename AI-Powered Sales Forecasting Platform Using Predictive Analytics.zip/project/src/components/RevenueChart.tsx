import { useState, useEffect, useRef } from 'react';
import type { RevenueForecast } from '../types';

interface RevenueChartProps {
  data: RevenueForecast[];
}

export function RevenueChart({ data }: RevenueChartProps) {
  const [hovered, setHovered] = useState<number | null>(null);
  const [animatedHeights, setAnimatedHeights] = useState<number[]>(data.map(() => 0));
  const containerRef = useRef<HTMLDivElement>(null);

  const maxRevenue = Math.max(...data.flatMap((d) => [d.projected_revenue, d.optimistic, d.conservative]), 1);

  useEffect(() => {
    const timer = setTimeout(() => {
      setAnimatedHeights(data.map(() => 1));
    }, 100);
    return () => clearTimeout(timer);
  }, [data]);

  function barHeight(value: number): number {
    return (value / maxRevenue) * 100;
  }

  function formatRevenue(value: number): string {
    if (value >= 1000000) return `$${(value / 1000000).toFixed(1)}M`;
    if (value >= 1000) return `$${(value / 1000).toFixed(0)}K`;
    return `$${value}`;
  }

  return (
    <div ref={containerRef} className="relative">
      {/* Legend */}
      <div className="flex items-center gap-4 mb-4">
        <div className="flex items-center gap-2">
          <span className="w-3 h-3 rounded-sm bg-primary-500" />
          <span className="text-xs text-neutral-400">Projected</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="w-3 h-3 rounded-sm bg-accent-500/40 border border-accent-500/60" />
          <span className="text-xs text-neutral-400">Optimistic</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="w-3 h-3 rounded-sm bg-warning-500/30 border border-warning-500/50" />
          <span className="text-xs text-neutral-400">Conservative</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="w-3 h-3 rounded-full bg-white/20" />
          <span className="text-xs text-neutral-400">Closed Won</span>
        </div>
      </div>

      {/* Chart */}
      <div className="flex items-end justify-between gap-2 h-48 px-2 relative">
        {/* Y-axis grid lines */}
        <div className="absolute inset-0 flex flex-col justify-between pointer-events-none">
          {[0, 25, 50, 75, 100].map((pct) => (
            <div key={pct} className="flex items-center gap-2">
              <span className="text-xs text-neutral-600 w-12 text-right">{formatRevenue(Math.round(maxRevenue * (100 - pct) / 100))}</span>
              <div className="flex-1 border-t border-neutral-800/50" />
            </div>
          ))}
        </div>

        {/* Bars */}
        {data.map((d, i) => (
          <div
            key={i}
            className="flex-1 flex flex-col items-center justify-end h-full relative group"
            onMouseEnter={() => setHovered(i)}
            onMouseLeave={() => setHovered(null)}
          >
            {/* Tooltip */}
            {hovered === i && (
              <div className="absolute -top-2 left-1/2 -translate-x-1/2 -translate-y-full z-20 bg-neutral-800 border border-neutral-700 rounded-lg p-3 shadow-xl whitespace-nowrap animate-fade-in">
                <p className="text-xs font-semibold text-white mb-1.5">{d.month}</p>
                <div className="space-y-1">
                  <p className="text-xs text-primary-400">Projected: {formatRevenue(d.projected_revenue)}</p>
                  <p className="text-xs text-accent-400">Optimistic: {formatRevenue(d.optimistic)}</p>
                  <p className="text-xs text-warning-400">Conservative: {formatRevenue(d.conservative)}</p>
                  <p className="text-xs text-neutral-400">Closed Won: {formatRevenue(d.closed_won_revenue)}</p>
                </div>
              </div>
            )}

            {/* Bar group */}
            <div className="flex items-end gap-1 w-full justify-center" style={{ height: '100%' }}>
              {/* Conservative bar */}
              <div
                className="w-3 rounded-t bg-warning-500/30 border border-warning-500/50 transition-all duration-700 ease-out"
                style={{ height: `${barHeight(d.conservative) * animatedHeights[i]}%` }}
              />
              {/* Projected bar (main) */}
              <div
                className="w-5 rounded-t bg-gradient-to-t from-primary-600 to-primary-400 transition-all duration-700 ease-out relative"
                style={{ height: `${barHeight(d.projected_revenue) * animatedHeights[i]}%` }}
              >
                {/* Closed Won marker */}
                {d.closed_won_revenue > 0 && (
                  <div
                    className="absolute left-1/2 -translate-x-1/2 w-3 h-3 rounded-full bg-white border-2 border-primary-500 shadow-lg -top-1.5"
                    style={{ bottom: `${barHeight(d.closed_won_revenue) * animatedHeights[i]}%` }}
                  />
                )}
              </div>
              {/* Optimistic bar */}
              <div
                className="w-3 rounded-t bg-accent-500/40 border border-accent-500/60 transition-all duration-700 ease-out"
                style={{ height: `${barHeight(d.optimistic) * animatedHeights[i]}%` }}
              />
            </div>

            {/* Month label */}
            <span className="text-xs text-neutral-500 mt-2">{d.month}</span>
          </div>
        ))}
      </div>

      {/* Summary stats */}
      <div className="grid grid-cols-3 gap-4 mt-6 pt-4 border-t border-neutral-800">
        <div>
          <p className="text-xs text-neutral-500">6-Month Total Projected</p>
          <p className="text-lg font-bold text-primary-400 mt-0.5">
            {formatRevenue(data.reduce((sum, d) => sum + d.projected_revenue, 0))}
          </p>
        </div>
        <div>
          <p className="text-xs text-neutral-500">Best Case (Optimistic)</p>
          <p className="text-lg font-bold text-accent-400 mt-0.5">
            {formatRevenue(data.reduce((sum, d) => sum + d.optimistic, 0))}
          </p>
        </div>
        <div>
          <p className="text-xs text-neutral-500">Worst Case (Conservative)</p>
          <p className="text-lg font-bold text-warning-400 mt-0.5">
            {formatRevenue(data.reduce((sum, d) => sum + d.conservative, 0))}
          </p>
        </div>
      </div>
    </div>
  );
}
