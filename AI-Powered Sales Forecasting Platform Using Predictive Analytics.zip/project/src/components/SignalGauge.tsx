import { useEffect, useState } from 'react';

interface SignalGaugeProps {
  score: number;
  size?: number;
  label?: string;
  conversionProbability?: number;
}

export function SignalGauge({ score, size = 160, label, conversionProbability }: SignalGaugeProps) {
  const [animatedScore, setAnimatedScore] = useState(0);
  const radius = (size - 20) / 2;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (animatedScore / 100) * circumference;

  useEffect(() => {
    const timer = setTimeout(() => setAnimatedScore(score), 100);
    return () => clearTimeout(timer);
  }, [score]);

  const color = score >= 80 ? '#10b981' : score >= 60 ? '#f59e0b' : score >= 40 ? '#fbbf24' : '#ef4444';
  const bgColor = score >= 80 ? 'rgba(16,185,129,0.1)' : score >= 60 ? 'rgba(245,158,11,0.1)' : 'rgba(239,68,68,0.1)';

  return (
    <div className="flex flex-col items-center justify-center" style={{ width: size, height: size }}>
      <svg width={size} height={size} className="transform -rotate-90">
        <circle cx={size / 2} cy={size / 2} r={radius} fill="none" stroke="#1e293b" strokeWidth="10" />
        <circle
          cx={size / 2}
          cy={size / 2}
          r={radius}
          fill="none"
          stroke={color}
          strokeWidth="10"
          strokeLinecap="round"
          strokeDasharray={circumference}
          strokeDashoffset={offset}
          style={{ transition: 'stroke-dashoffset 1.2s ease-out' }}
        />
      </svg>
      <div className="absolute flex flex-col items-center justify-center" style={{ width: size, height: size }}>
        <span className="text-3xl font-bold" style={{ color }}>
          {animatedScore}
        </span>
        <span className="text-xs text-neutral-500 mt-0.5">Signal Score</span>
        {conversionProbability !== undefined && (
          <span className="text-xs text-neutral-400 mt-1">{conversionProbability}% conversion</span>
        )}
      </div>
      {label && <span className="text-xs text-neutral-500 mt-2">{label}</span>}
    </div>
  );
}
