export type LeadStatus = 'New' | 'Qualified' | 'Proposal' | 'Negotiation' | 'Closed Won' | 'Closed Lost';
export type Priority = 'High' | 'Medium' | 'Low';

export interface Lead {
  id: string;
  company_name: string;
  industry: string;
  contact_name: string;
  contact_title: string;
  email: string;
  phone: string;
  website: string;
  location: string;
  company_size: string;
  annual_revenue: string;
  funding_stage: string;
  technology_stack: string[];
  lead_status: LeadStatus;
  priority: Priority;
  notes: string;
  created_at: string;
  updated_at: string;
}

export interface ScoringFactor {
  factor: string;
  points: number;
  note?: string;
}

export interface KeySignal {
  signal: string;
  points: number;
  detail: string;
}

export interface LeadScore {
  id: string;
  lead_id: string;
  lead_score: number;
  conversion_probability: number;
  scoring_factors: ScoringFactor[];
  qualification_label: string;
  generated_at: string;
}

export interface CompanyInsight {
  id: string;
  lead_id: string;
  business_needs: string;
  opportunities: string;
  industry_analysis: string;
  key_signals: KeySignal[];
  generated_at: string;
}

export type OutreachChannel = 'email' | 'linkedin' | 'call_script' | 'objection_handling';

export interface ObjectionResponse {
  objection: string;
  response: string;
}

export interface OutreachCampaign {
  id: string;
  lead_id: string;
  email_subject: string;
  email_content: string;
  campaign_status: 'Draft' | 'Sent' | 'Opened' | 'Replied' | 'Bounced';
  outreach_strategy: Record<string, string>;
  channel_type?: OutreachChannel;
  linkedin_message?: string;
  call_script?: string;
  objection_responses?: ObjectionResponse[];
  created_at: string;
}

export interface RevenueForecast {
  month: string;
  projected_revenue: number;
  conservative: number;
  optimistic: number;
  closed_won_revenue: number;
}

export interface ActionItem {
  owner: string;
  action: string;
  due: string;
}

export interface SalesInteraction {
  id: string;
  lead_id: string;
  interaction_type: 'Call' | 'Meeting' | 'Email' | 'Demo' | 'Follow-up';
  transcript: string;
  summary: string;
  key_points: { point: string }[];
  action_items: ActionItem[];
  duration_minutes: number;
  interaction_date: string;
}

export interface CrmSyncLog {
  id: string;
  lead_id: string;
  crm_platform: string;
  sync_status: 'Pending' | 'Synced' | 'Failed';
  sync_type: string;
  details: string;
  timestamp: string;
}

export interface FollowUpRecommendation {
  id: string;
  lead_id: string;
  recommendation: string;
  priority: Priority;
  recommended_action: string;
  timing: string;
  generated_at: string;
}

export interface SalesAnalytics {
  id: string;
  period: string;
  conversion_rate: number;
  pipeline_value: number;
  avg_response_time_hours: number;
  avg_sales_cycle_days: number;
  total_leads: number;
  qualified_leads: number;
  closed_won: number;
  closed_lost: number;
  generated_at: string;
}
