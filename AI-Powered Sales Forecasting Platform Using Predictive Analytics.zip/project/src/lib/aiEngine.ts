import type { Lead, ScoringFactor, KeySignal, ObjectionResponse, RevenueForecast } from '../types';

// Deterministic, explainable heuristic AI engine.
// Mirrors the server-side edge function logic so the app is always demoable
// without an external LLM. Each function returns structured JSON.

export function analyzeCompany(lead: Lead) {
  const signals: KeySignal[] = [];

  if (lead.funding_stage) {
    const stagePoints: Record<string, number> = {
      Seed: 10,
      'Series A': 18,
      'Series B': 22,
      'Series C': 25,
      'Series D': 28,
    };
    signals.push({
      signal: `${lead.funding_stage} Funding`,
      points: stagePoints[lead.funding_stage] ?? 12,
      detail: `Recent ${lead.funding_stage} raise indicates growth budget`,
    });
  }

  if (lead.technology_stack.length > 0) {
    signals.push({
      signal: 'Tech Stack Alignment',
      points: 20,
      detail: `${lead.technology_stack.slice(0, 3).join(', ')} matches integration profile`,
    });
  }

  if (lead.contact_title) {
    const isDecisionMaker = /CTO|CEO|CISO|VP|Director|Head/i.test(lead.contact_title);
    signals.push({
      signal: isDecisionMaker ? 'Decision-Maker Contact' : 'Influencer Contact',
      points: isDecisionMaker ? 15 : 8,
      detail: `${lead.contact_title} is ${isDecisionMaker ? 'a decision maker' : 'an influencer'}`,
    });
  }

  if (lead.company_size) {
    signals.push({
      signal: 'Company Size',
      points: 10,
      detail: `${lead.company_size} in target range`,
    });
  }

  const needs = `${lead.company_name} in the ${lead.industry} sector is at the ${lead.funding_stage} stage with ${lead.company_size}. Based on their profile, they likely need to scale infrastructure, optimize operations, and invest in tooling that supports their next growth phase. Their current technology stack (${lead.technology_stack.join(', ') || 'not disclosed'}) suggests a modern engineering organization ready to adopt new platforms.`;

  const opportunities = `With ${lead.funding_stage} funding and ${lead.company_size}, ${lead.company_name} represents a strong expansion opportunity. ${lead.contact_title ? `${lead.contact_name} (${lead.contact_title}) is ` : 'They are '}likely evaluating vendors now, and budget availability is high post-funding. The ${lead.industry} industry is seeing accelerated tooling adoption, making this an ideal entry window.`;

  const industryAnalysis = `The ${lead.industry} sector is experiencing rapid digital transformation. Companies at the ${lead.funding_stage} stage typically allocate 15-20% of new funding to infrastructure and tooling. ${lead.company_name}'s use of ${lead.technology_stack.slice(0, 2).join(' and ') || 'modern technologies'} signals engineering maturity and openness to adopting new platforms.`;

  return {
    business_needs: needs,
    opportunities,
    industry_analysis: industryAnalysis,
    key_signals: signals,
  };
}

export function scoreLead(lead: Lead) {
  const factors: ScoringFactor[] = [];
  let score = 0;

  // Funding stage weighting
  const fundingWeights: Record<string, number> = {
    Seed: 10,
    'Series A': 18,
    'Series B': 22,
    'Series C': 25,
    'Series D': 28,
  };
  if (lead.funding_stage && fundingWeights[lead.funding_stage]) {
    const pts = fundingWeights[lead.funding_stage];
    score += pts;
    factors.push({ factor: 'Funding Stage', points: pts, note: `${lead.funding_stage} indicates growth budget` });
  }

  // Tech stack alignment
  const stackOverlap = lead.technology_stack.length;
  if (stackOverlap > 0) {
    const pts = Math.min(stackOverlap * 3, 20);
    score += pts;
    factors.push({ factor: 'Tech Stack Alignment', points: pts, note: `${stackOverlap} technologies matched` });
  }

  // Decision-maker seniority
  if (lead.contact_title) {
    const isDecisionMaker = /CTO|CEO|CISO|VP|Director|Head/i.test(lead.contact_title);
    const pts = isDecisionMaker ? 18 : 8;
    score += pts;
    factors.push({ factor: 'Contact Seniority', points: pts, note: isDecisionMaker ? 'Decision-maker' : 'Influencer' });
  }

  // Company size
  if (lead.company_size) {
    const isMidMarket = /50-200|200-500|250-500|100-250/.test(lead.company_size);
    const isEnterprise = /500-1000|1000+/.test(lead.company_size);
    const pts = isEnterprise ? 15 : isMidMarket ? 12 : 6;
    score += pts;
    factors.push({ factor: 'Company Size', points: pts, note: lead.company_size });
  }

  // Industry relevance
  if (lead.industry) {
    const pts = 10;
    score += pts;
    factors.push({ factor: 'Industry Fit', points: pts, note: lead.industry });
  }

  // Revenue signal
  if (lead.annual_revenue) {
    const pts = 8;
    score += pts;
    factors.push({ factor: 'Revenue Signal', points: pts, note: lead.annual_revenue });
  }

  score = Math.min(score, 100);
  const conversionProbability = Math.round(score * 0.85);
  const label = score >= 80 ? 'Highly Qualified' : score >= 60 ? 'Qualified' : score >= 40 ? 'Warm' : 'Cold';

  return {
    lead_score: score,
    conversion_probability: conversionProbability,
    scoring_factors: factors,
    qualification_label: label,
  };
}

export function generateOutreach(lead: Lead, insight: { business_needs: string; opportunities: string } | null, score: { lead_score: number; qualification_label: string } | null) {
  const firstName = lead.contact_name.split(' ')[0] || 'there';
  const fundingHook = lead.funding_stage ? `Congratulations on ${lead.company_name}'s ${lead.funding_stage} milestone` : `I've been following ${lead.company_name}'s growth`;
  const signal = score && score.lead_score >= 80 ? 'a clear fit' : 'an interesting alignment';

  const subject = `${lead.industry} Intelligence for ${lead.company_name} — ${signal === 'a clear fit' ? 'Strong Fit' : 'Worth Exploring'}`;

  const content = `Hi ${firstName},

${fundingHook} — it's a strong signal of your team's execution and momentum in the ${lead.industry} space.

${insight ? `Based on your profile, companies at your stage typically face a critical inflection point: ${insight.business_needs.split('.')[0]}.` : `Based on your company's profile and growth stage, there's likely a pressing need to scale operations efficiently.`}

Our platform has helped similar ${lead.industry} companies reduce operational overhead by 35-40% while supporting 3x growth — all without disrupting your existing stack${lead.technology_stack.length > 0 ? ` (${lead.technology_stack.slice(0, 2).join(', ')})` : ''}.

${score && score.lead_score >= 80 ? 'Given the strong alignment, I believe we can deliver immediate value.' : 'I think there\'s a meaningful conversation to be had here.'}

Would a 20-minute walkthrough make sense this week?

Best,
Alex Thompson
AI-Powered Sales Forecasting Platform`;

  return {
    email_subject: subject,
    email_content: content,
    outreach_strategy: {
      followUpTiming: 'Tuesday 10:00 AM',
      channel: 'Email → LinkedIn',
      contentStrategy: score && score.lead_score >= 80 ? 'ROI + peer case study' : 'Pain point + curiosity',
      priority: lead.priority,
    },
  };
}

export function summarizeConversation(transcript: string, lead?: Lead) {
  const text = transcript.trim();
  const sentences = text
    .split(/[.!?]+/)
    .map((s) => s.trim())
    .filter((s) => s.length > 8);

  const company = lead?.company_name ?? 'the prospect';
  const contact = lead?.contact_name ?? 'the contact';
  const industry = lead?.industry ?? 'their industry';

  const lower = text.toLowerCase();

  // Detect topics mentioned in the transcript
  const topics: string[] = [];
  if (/budget|pricing|cost|price|afford|quote|roi|return on investment/i.test(text)) topics.push('budget and pricing');
  if (/timeline|deadline|when|schedule|launch|target date/i.test(text)) topics.push('timeline and deadlines');
  if (/integration|api|connect|compatible|stack|platform/i.test(text)) topics.push('technical integration');
  if (/demo|walkthrough|presentation|showcase/i.test(text)) topics.push('product demonstration');
  if (/competitor|alternative|comparison|other vendor/i.test(text)) topics.push('competitive landscape');
  if (/team|stakeholder|decision|approv|buy-in|champion/i.test(text)) topics.push('team and decision-making');
  if (/concern|objection|risk|worried|hesitant|challenge/i.test(text)) topics.push('concerns and objections');
  if (/next step|follow up|followup|action item|to-do|todo/i.test(text)) topics.push('next steps');
  if (/feature|capability|functionality|use case|solution/i.test(text)) topics.push('solution fit and features');
  if (/funding|raised|series|investment|valuation/i.test(text)) topics.push('funding and growth');

  // Detect sentiment
  const positiveWords = (text.match(/\binterested|excited|impressed|great|perfect|love|exactly|yes|absolutely|definitely|looking forward|sounds good\b/gi) || []).length;
  const negativeWords = (text.match(/\bconcern|worried|expensive|complicated|not sure|maybe|later|issue|problem|hesitant\b/gi) || []).length;
  const sentiment = positiveWords > negativeWords + 1 ? 'positive' : negativeWords > positiveWords + 1 ? 'cautious' : 'neutral';

  // Build a synthesized summary (not just truncated sentences)
  const topicList = topics.length > 0 ? topics.join(', ') : 'general introduction and needs assessment';
  const summary = `Conversation with ${contact} from ${company} covered ${topicList}. ` +
    `The discussion explored how ${company}'s ${industry} operations could benefit from the platform, ` +
    `with ${sentiment === 'positive' ? 'strong engagement and clear interest in moving forward' : sentiment === 'cautious' ? 'some hesitations that would need to be addressed before a decision' : 'a balanced exploration of needs and capabilities'}. ` +
    `${topics.includes('concerns and objections') ? 'Key concerns were raised around fit and timing, which should be addressed in follow-up. ' : ''}` +
    `The interaction lasted ${text.length > 500 ? 'an in-depth' : 'a focused'} session with ${sentences.length} discussion points captured.`;

  // Extract key points — pick the most substantive sentences
  const scored = sentences.map((s, i) => {
    let score = 0;
    if (/budget|pricing|cost|roi/i.test(s)) score += 3;
    if (/timeline|deadline|launch/i.test(s)) score += 3;
    if (/integration|api|platform|stack/i.test(s)) score += 2;
    if (/need|require|looking for|want|problem|challenge/i.test(s)) score += 2;
    if (/interested|excited|impressed/i.test(s)) score += 2;
    if (/concern|worried|not sure|hesitant/i.test(s)) score += 2;
    if (/next step|follow up|schedule|send|prepare/i.test(s)) score += 3;
    if (s.length > 40 && s.length < 200) score += 1;
    if (i < 2) score += 1;
    return { s, score, i };
  });
  const keyPoints = scored
    .sort((a, b) => b.score - a.score)
    .slice(0, 5)
    .sort((a, b) => a.i - b.i)
    .map(({ s }) => ({ point: s }));

  // Extract action items
  const actionKeywords = ['need to', 'should', 'will', "let's", 'schedule', 'send over', 'prepare', 'follow up', 'review', 'get back', 'circle back', 'put together', 'share'];
  const actionItems = sentences
    .filter((s) => actionKeywords.some((k) => s.toLowerCase().includes(k)))
    .slice(0, 4)
    .map((s) => {
      let owner = 'Sales Rep';
      if (/they|their|contact|prospect/i.test(s)) owner = contact;
      let due = 'Next week';
      if (/today|tomorrow|asap|right away|end of day/i.test(s)) due = 'Today';
      else if (/this week|by friday|by monday/i.test(s)) due = 'This week';
      else if (/next week|next monday/i.test(s)) due = 'Next week';
      return { owner, action: s, due };
    });

  // If no action items detected but next steps were discussed, synthesize one
  if (actionItems.length === 0 && /next step|follow up|move forward|proceed/i.test(lower)) {
    actionItems.push({
      owner: 'Sales Rep',
      action: `Send ${contact} a follow-up email with next steps and scheduling link`,
      due: 'Within 48 hours',
    });
  }

  return {
    summary,
    key_points: keyPoints,
    action_items: actionItems,
  };
}

export function generateFollowupRecommendations(lead: Lead, score: { lead_score: number } | null) {
  const recs: { recommendation: string; priority: 'High' | 'Medium' | 'Low'; recommended_action: string; timing: string }[] = [];

  if (score && score.lead_score >= 80) {
    recs.push({
      recommendation: `${lead.contact_name} is a high-value prospect (${score.lead_score}/100). Prioritize immediate follow-up while interest is fresh.`,
      priority: 'High',
      recommended_action: 'Schedule a personalized call within 24 hours',
      timing: 'Today',
    });
  } else if (score && score.lead_score >= 60) {
    recs.push({
      recommendation: `${lead.company_name} shows solid qualification signals. Nurture with targeted content.`,
      priority: 'Medium',
      recommended_action: 'Send industry case study and schedule follow-up',
      timing: 'Within 48 hours',
    });
  } else {
    recs.push({
      recommendation: `${lead.company_name} needs more discovery before prioritization. Qualify budget and timeline.`,
      priority: 'Low',
      recommended_action: 'Send qualification questionnaire',
      timing: 'Within 1 week',
    });
  }

  if (lead.funding_stage && lead.funding_stage !== 'Seed') {
    recs.push({
      recommendation: `${lead.company_name} recently raised ${lead.funding_stage} funding — reference this in outreach for higher engagement.`,
      priority: 'High',
      recommended_action: 'Personalize outreach with funding milestone mention',
      timing: 'Next outreach cycle',
    });
  }

  recs.push({
    recommendation: `Connect with ${lead.contact_name} on LinkedIn to build rapport before the next touchpoint.`,
    priority: 'Medium',
    recommended_action: 'Send LinkedIn connection request with personalized note',
    timing: 'Within 24 hours',
  });

  return recs;
}

// AI-driven CRM sync: determines what data to sync, to which CRM object,
// and generates a human-readable summary of what changed and why it matters.
export function generateCrmSyncActivity(lead: Lead, score: { lead_score: number; qualification_label: string } | null) {
  const isHighPriority = score ? score.lead_score >= 80 : lead.priority === 'High';
  const isQualified = lead.lead_status !== 'New';

  const syncType = isQualified ? 'Status Update' : 'Contact Added';
  const crmObject = isHighPriority ? 'Opportunity' : 'Lead';

  const changes: string[] = [];
  if (lead.lead_status === 'New') changes.push('Created new Lead record');
  if (lead.lead_status === 'Qualified') changes.push('Updated Lead stage to Qualified');
  if (lead.lead_status === 'Proposal') changes.push('Created Opportunity in Proposal stage');
  if (lead.lead_status === 'Negotiation') changes.push('Moved Opportunity to Negotiation');
  if (lead.lead_status === 'Closed Won') changes.push('Closed Opportunity as Won');

  if (score) {
    changes.push(`Synced AI signal score: ${score.lead_score}/100 (${score.qualification_label})`);
  }
  if (lead.funding_stage && lead.funding_stage !== 'Seed') {
    changes.push(`Tagged funding signal: ${lead.funding_stage}`);
  }
  if (lead.technology_stack.length > 0) {
    changes.push(`Updated tech stack: ${lead.technology_stack.slice(0, 3).join(', ')}`);
  }

  const summary = isHighPriority
    ? `${lead.company_name} flagged as high-priority (${score?.lead_score ?? '?'}/100). Auto-synced to CRM as ${crmObject} with enriched signals. Recommended for immediate sales follow-up.`
    : isQualified
      ? `${lead.company_name} synced to CRM. Lead stage updated to ${lead.lead_status}. AI enrichment applied — tech stack, funding signals, and contact seniority captured.`
      : `${lead.company_name} added to CRM as new Lead. AI enrichment pending — run intelligence pipeline for full scoring.`;

  return {
    sync_type: syncType,
    crm_object: crmObject,
    changes,
    summary,
    priority: isHighPriority ? 'High' as const : lead.priority === 'Medium' ? 'Medium' as const : 'Low' as const,
  };
}

// ---- LINKEDIN INMAIL GENERATION ----
export function generateLinkedInInMail(
  lead: Lead,
  insight: { business_needs: string; opportunities: string } | null,
  score: { lead_score: number; qualification_label: string } | null,
) {
  const firstName = lead.contact_name.split(' ')[0] || 'there';
  const isHighFit = score && score.lead_score >= 80;

  const subject = isHighFit
    ? `${lead.company_name} + AI-driven sales forecasting — quick connect?`
    : `Following ${lead.company_name}'s growth in ${lead.industry}`;

  const message = `Hi ${firstName},

I came across ${lead.company_name}'s work in the ${lead.industry} space${lead.funding_stage ? ` and the recent ${lead.funding_stage} round` : ''} — impressive momentum.

${insight ? `I help companies like yours tackle challenges around ${insight.business_needs.split('.')[0].toLowerCase()}.` : `I work with ${lead.industry} companies to help them scale their sales operations with predictive analytics.`}

${isHighFit ? 'Based on your profile, I think there\'s a strong fit.' : 'Would love to learn more about your current priorities.'}

Open to a quick chat this week?

Best,
Alex Thompson
AI-Powered Sales Forecasting Platform`;

  return {
    linkedin_subject: subject,
    linkedin_message: message,
    outreach_strategy: {
      followUpTiming: '3 days',
      channel: 'LinkedIn InMail',
      contentStrategy: isHighFit ? 'Direct fit + social proof' : 'Curiosity + rapport',
      priority: lead.priority,
    },
  };
}

// ---- CALL SCRIPT GENERATION ----
export function generateCallScript(
  lead: Lead,
  insight: { business_needs: string; opportunities: string } | null,
  score: { lead_score: number; qualification_label: string } | null,
) {
  const firstName = lead.contact_name.split(' ')[0] || 'there';
  const isHighFit = score && score.lead_score >= 80;

  const opener = `Hi ${firstName}, this is Alex from AI-Powered Sales Forecasting Platform. I'll keep this brief — I noticed ${lead.company_name}${lead.funding_stage ? ` recently closed a ${lead.funding_stage} round` : ''} and I work with ${lead.industry} companies on scaling sales operations with predictive analytics.`;

  const valueProp = `${insight ? insight.business_needs.split('.')[0] : 'Many companies at your stage struggle with manual lead qualification and forecasting accuracy'}. Our platform uses AI to score leads 0–100 with explainable signals, generate personalized outreach, and forecast revenue — all in one workspace.`;

  const qualification = [
    `How are you currently handling lead scoring and sales forecasting?`,
    `What tools are in your sales stack today?${lead.technology_stack.length > 0 ? ` I see you use ${lead.technology_stack.slice(0, 2).join(' and ')}.` : ''}`,
    `Is improving forecast accuracy a priority this quarter?`,
  ];

  const close = isHighFit
    ? `Based on what you've shared, I think we could deliver immediate value. Would a 20-minute demo this week work?`
    : `I'd love to show you a quick demo and see if there's a fit. Does next week work for a 20-minute call?`;

  const script = `CALL SCRIPT — ${lead.company_name} / ${lead.contact_name}

[OPENER]
${opener}

[VALUE PROPOSITION]
${valueProp}

[QUALIFICATION QUESTIONS]
${qualification.map((q, i) => `${i + 1}. ${q}`).join('\n')}

[CLOSE]
${close}

[NOTES]
- Priority: ${lead.priority}
- Score: ${score ? score.lead_score + '/100' : 'Not scored yet'}
- Industry: ${lead.industry}
- Funding: ${lead.funding_stage || 'Unknown'}
- Tech Stack: ${lead.technology_stack.join(', ') || 'Not disclosed'}`;

  return {
    call_script: script,
    outreach_strategy: {
      followUpTiming: 'Within 24 hours',
      channel: 'Phone Call',
      contentStrategy: isHighFit ? 'ROI-focused + demo offer' : 'Discovery + value tease',
      priority: lead.priority,
    },
  };
}

// ---- OBJECTION HANDLING ----
export function generateObjectionHandling(
  lead: Lead,
  score: { lead_score: number; qualification_label: string } | null,
): ObjectionResponse[] {
  const isHighFit = score && score.lead_score >= 80;

  return [
    {
      objection: '"Send me some information instead."',
      response: `I'd be happy to send info, ${lead.contact_name.split(' ')[0] || 'there'}. To make sure I send the most relevant material — are you more interested in how our AI scoring works, or in the revenue forecasting side? I can also share a 2-minute demo video if that's easier.`,
    },
    {
      objection: '"We already have a CRM / sales tool."',
      response: `That's great — we actually integrate alongside existing CRMs rather than replacing them. Our platform adds AI lead scoring and predictive forecasting on top of your current setup. What are you using today? I'd love to show how we complement it.`,
    },
    {
      objection: '"It\'s too expensive / not in the budget."',
      response: `I understand. Many of our ${lead.industry} clients started with the same concern. The platform typically pays for itself within the first quarter by improving conversion rates by 30–40%. We also offer flexible pricing. Would it help if I put together an ROI analysis specific to ${lead.company_name}?`,
    },
    {
      objection: '"I don\'t have time right now."',
      response: `Completely understand — I know ${lead.funding_stage ? `post-${lead.funding_stage}` : 'at your stage'} things move fast. How about I send a 2-minute video overview, and we schedule a proper call when things calm down? What does your calendar look like in 2 weeks?`,
    },
    {
      objection: '"I need to check with my team / boss."',
      response: `Absolutely, that makes sense. What I'd suggest is a 15-minute group demo where I can address everyone's questions at once. Who else should be involved in the evaluation? I can send a calendar invite that works for the whole team.`,
    },
    {
      objection: '"We\'re not ready for AI yet."',
      response: `That's actually a common starting point. Our platform is designed to be plug-and-play — no ML expertise needed. The AI runs in the background and presents results in plain English with explainable scores. ${isHighFit ? 'Given your tech stack, your team would adapt very quickly.' : 'Many clients started exactly where you are now.'} Would a quick no-pressure demo help?`,
    },
    {
      objection: '"How is this different from [competitor]?"',
      response: `Great question. Unlike traditional sales tools that just track activity, our platform uses predictive analytics to score leads 0–100 with explainable signals, auto-generate personalized outreach across email and LinkedIn, and forecast revenue from your pipeline. The AI is provider-agnostic — no vendor lock-in. I'd be happy to walk you through a side-by-side comparison.`,
    },
  ];
}

// ---- REVENUE FORECASTING ----
export function generateRevenueForecast(
  leads: Lead[],
  scoreMap: Record<string, number>,
  analytics: { pipeline_value: number; conversion_rate: number; closed_won: number } | null,
): RevenueForecast[] {
  const now = new Date();
  const months: RevenueForecast[] = [];

  const scoredLeads = leads.filter((l) => scoreMap[l.id] !== undefined);
  const avgScore = scoredLeads.length > 0
    ? scoredLeads.reduce((sum, l) => sum + scoreMap[l.id], 0) / scoredLeads.length
    : 50;

  const activeLeads = leads.filter((l) =>
    l.lead_status === 'New' || l.lead_status === 'Qualified' ||
    l.lead_status === 'Proposal' || l.lead_status === 'Negotiation'
  );

  const basePipelineValue = analytics?.pipeline_value ?? activeLeads.length * 50000;
  const baseConversionRate = analytics?.conversion_rate ?? 25;

  const stageWeights: Record<string, number> = {
    'New': 0.10,
    'Qualified': 0.25,
    'Proposal': 0.50,
    'Negotiation': 0.75,
    'Closed Won': 1.0,
    'Closed Lost': 0.0,
  };

  const weightedPipeline = leads.reduce((sum, l) => {
    const weight = stageWeights[l.lead_status] ?? 0.10;
    const scoreBoost = (scoreMap[l.id] ?? 50) / 100;
    const dealValue = 50000;
    return sum + dealValue * weight * scoreBoost;
  }, 0);

  const closedWonRevenue = (analytics?.closed_won ?? 0) * 50000;

  for (let i = 0; i < 6; i++) {
    const date = new Date(now.getFullYear(), now.getMonth() + i, 1);
    const monthLabel = date.toLocaleDateString('en-US', { month: 'short', year: '2-digit' });

    const growthFactor = 1 + i * 0.08;
    const seasonalFactor = i === 0 ? 0.9 : i === 5 ? 1.15 : 1.0;

    const projected = Math.round(weightedPipeline * growthFactor * seasonalFactor * (baseConversionRate / 100));
    const conservative = Math.round(projected * 0.7);
    const optimistic = Math.round(projected * 1.3);
    const closedRevenue = i === 0 ? closedWonRevenue : Math.round(closedWonRevenue * growthFactor * 0.8);

    months.push({
      month: monthLabel,
      projected_revenue: projected,
      conservative,
      optimistic,
      closed_won_revenue: closedRevenue,
    });
  }

  return months;
}

// Full agentic pipeline: analyze → score → outreach → follow-ups
export async function runIntelligencePipeline(lead: Lead) {
  const insight = analyzeCompany(lead);
  const score = scoreLead(lead);
  const outreach = generateOutreach(lead, insight, score);
  const followups = generateFollowupRecommendations(lead, score);

  return { insight, score, outreach, followups };
}
