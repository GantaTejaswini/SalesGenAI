import { supabase } from './supabase';
import {
  analyzeCompany,
  scoreLead,
  generateOutreach,
  generateLinkedInInMail,
  generateCallScript,
  generateObjectionHandling,
  generateRevenueForecast,
  summarizeConversation,
  generateFollowupRecommendations,
  generateCrmSyncActivity,
} from './aiEngine';
import {
  analyseLead as apiAnalyseLead,
  generateEmail as apiGenerateEmail,
  analyseMeeting as apiAnalyseMeeting,
  fullPipeline as apiFullPipeline,
  checkHealth,
  type ApiInsight,
  type ApiScore,
  type ApiEmail,
  type ApiConversation,
  type ApiFollowUp,
} from './backend';
import type {
  Lead,
  LeadScore,
  CompanyInsight,
  OutreachCampaign,
  OutreachChannel,
  ObjectionResponse,
  RevenueForecast,
  SalesInteraction,
  CrmSyncLog,
  FollowUpRecommendation,
  SalesAnalytics,
  KeySignal,
  ScoringFactor,
  ActionItem,
} from '../types';

// ---- LEADS ----
export async function fetchLeads(): Promise<Lead[]> {
  const { data, error } = await supabase.from('leads').select('*').order('created_at', { ascending: false });
  if (error) throw error;
  return (data ?? []) as Lead[];
}

export async function fetchLead(id: string): Promise<Lead | null> {
  const { data, error } = await supabase.from('leads').select('*').eq('id', id).maybeSingle();
  if (error) throw error;
  return data as Lead | null;
}

export async function createLead(lead: Omit<Lead, 'id' | 'created_at' | 'updated_at'>): Promise<Lead> {
  const { data, error } = await supabase.from('leads').insert(lead).select().single();
  if (error) throw error;
  return data as Lead;
}

export async function updateLead(id: string, updates: Partial<Lead>): Promise<Lead> {
  const { data, error } = await supabase.from('leads').update({ ...updates, updated_at: new Date().toISOString() }).eq('id', id).select().single();
  if (error) throw error;
  return data as Lead;
}

export async function deleteLead(id: string): Promise<void> {
  const { error } = await supabase.from('leads').delete().eq('id', id);
  if (error) throw error;
}

// ---- COMPANY INSIGHTS ----
export async function fetchInsights(leadId: string): Promise<CompanyInsight[]> {
  const { data, error } = await supabase.from('company_insights').select('*').eq('lead_id', leadId).order('generated_at', { ascending: false });
  if (error) throw error;
  return (data ?? []) as CompanyInsight[];
}

export async function analyzeLeadCompany(lead: Lead): Promise<CompanyInsight> {
  let row: Omit<CompanyInsight, 'id' | 'lead_id' | 'generated_at'>;

  if (await checkHealth()) {
    try {
      const { insight } = await apiAnalyseLead(lead);
      row = {
        business_needs: insight.business_needs,
        opportunities: insight.opportunities,
        industry_analysis: insight.industry_analysis,
        key_signals: [
          { signal: 'Qualification Score', points: insight.qualification_score, detail: insight.qualification_reasoning },
        ],
      };
    } catch {
      row = analyzeCompany(lead);
    }
  } else {
    row = analyzeCompany(lead);
  }

  const { data, error } = await supabase.from('company_insights').insert({ lead_id: lead.id, ...row }).select().single();
  if (error) throw error;
  return data as CompanyInsight;
}

// ---- LEAD SCORES ----
export async function fetchScores(leadId: string): Promise<LeadScore[]> {
  const { data, error } = await supabase.from('lead_scores').select('*').eq('lead_id', leadId).order('generated_at', { ascending: false });
  if (error) throw error;
  return (data ?? []) as LeadScore[];
}

export async function scoreLeadApi(lead: Lead): Promise<LeadScore> {
  let row: Omit<LeadScore, 'id' | 'lead_id' | 'generated_at'>;

  if (await checkHealth()) {
    try {
      const { score } = await apiAnalyseLead(lead);
      const label = score.priority_level === 'Hot' ? 'Highly Qualified' : score.priority_level === 'Warm' ? 'Qualified' : 'Cold';
      row = {
        lead_score: score.lead_score,
        conversion_probability: Math.round(score.conversion_probability * 100),
        scoring_factors: [{ factor: 'AI Assessment', points: score.lead_score, note: score.scoring_factors }],
        qualification_label: label,
      };
    } catch {
      row = scoreLead(lead);
    }
  } else {
    row = scoreLead(lead);
  }

  const { data, error } = await supabase.from('lead_scores').insert({ lead_id: lead.id, ...row }).select().single();
  if (error) throw error;
  return data as LeadScore;
}

// ---- OUTREACH ----
export async function fetchOutreach(leadId: string): Promise<OutreachCampaign[]> {
  const { data, error } = await supabase.from('outreach_campaigns').select('*').eq('lead_id', leadId).order('created_at', { ascending: false });
  if (error) throw error;
  return (data ?? []) as OutreachCampaign[];
}

export async function generateOutreachApi(
  lead: Lead,
  insight: { business_needs: string; opportunities: string } | null,
  score: { lead_score: number; qualification_label: string } | null,
): Promise<OutreachCampaign> {
  let row: Omit<OutreachCampaign, 'id' | 'lead_id' | 'created_at' | 'campaign_status'>;

  if (await checkHealth()) {
    try {
      const email = await apiGenerateEmail(lead);
      row = {
        email_subject: email.subject,
        email_content: email.body,
        outreach_strategy: {
          followUpTiming: email.follow_up_timing,
          channel: email.channel_recommendation,
          priority: lead.priority,
        },
      };
    } catch {
      row = generateOutreach(lead, insight, score);
    }
  } else {
    row = generateOutreach(lead, insight, score);
  }

  // Replace any existing Draft for this lead so the view always shows one fresh email
  await supabase.from('outreach_campaigns').delete().eq('lead_id', lead.id).eq('campaign_status', 'Draft');
  const { data, error } = await supabase.from('outreach_campaigns').insert({ lead_id: lead.id, ...row, campaign_status: 'Draft' }).select().single();
  if (error) throw error;
  return data as OutreachCampaign;
}

export async function updateOutreachStatus(id: string, status: OutreachCampaign['campaign_status']): Promise<void> {
  const { error } = await supabase.from('outreach_campaigns').update({ campaign_status: status }).eq('id', id);
  if (error) throw error;
}

export async function updateOutreachContent(id: string, subject: string, content: string): Promise<void> {
  const { error } = await supabase.from('outreach_campaigns').update({ email_subject: subject, email_content: content }).eq('id', id);
  if (error) throw error;
}

// ---- MULTI-CHANNEL OUTREACH ----
export async function generateLinkedInOutreachApi(
  lead: Lead,
  insight: { business_needs: string; opportunities: string } | null,
  score: { lead_score: number; qualification_label: string } | null,
): Promise<OutreachCampaign> {
  const linkedin = generateLinkedInInMail(lead, insight, score);

  await supabase.from('outreach_campaigns').delete().eq('lead_id', lead.id).eq('channel_type', 'linkedin').eq('campaign_status', 'Draft');

  const { data, error } = await supabase.from('outreach_campaigns').insert({
    lead_id: lead.id,
    email_subject: linkedin.linkedin_subject,
    email_content: '',
    channel_type: 'linkedin',
    linkedin_message: linkedin.linkedin_message,
    outreach_strategy: linkedin.outreach_strategy,
    campaign_status: 'Draft',
  }).select().single();
  if (error) throw error;
  return data as OutreachCampaign;
}

export async function generateCallScriptApi(
  lead: Lead,
  insight: { business_needs: string; opportunities: string } | null,
  score: { lead_score: number; qualification_label: string } | null,
): Promise<OutreachCampaign> {
  const callScript = generateCallScript(lead, insight, score);

  await supabase.from('outreach_campaigns').delete().eq('lead_id', lead.id).eq('channel_type', 'call_script').eq('campaign_status', 'Draft');

  const { data, error } = await supabase.from('outreach_campaigns').insert({
    lead_id: lead.id,
    email_subject: `Call Script — ${lead.company_name}`,
    email_content: '',
    channel_type: 'call_script',
    call_script: callScript.call_script,
    outreach_strategy: callScript.outreach_strategy,
    campaign_status: 'Draft',
  }).select().single();
  if (error) throw error;
  return data as OutreachCampaign;
}

export async function generateObjectionHandlingApi(
  lead: Lead,
  score: { lead_score: number; qualification_label: string } | null,
): Promise<OutreachCampaign> {
  const objections = generateObjectionHandling(lead, score);

  await supabase.from('outreach_campaigns').delete().eq('lead_id', lead.id).eq('channel_type', 'objection_handling').eq('campaign_status', 'Draft');

  const { data, error } = await supabase.from('outreach_campaigns').insert({
    lead_id: lead.id,
    email_subject: `Objection Handling — ${lead.company_name}`,
    email_content: '',
    channel_type: 'objection_handling',
    objection_responses: objections,
    outreach_strategy: { channel: 'Sales Enablement', priority: lead.priority, followUpTiming: 'Reference guide', contentStrategy: 'Pre-call prep' },
    campaign_status: 'Draft',
  }).select().single();
  if (error) throw error;
  return data as OutreachCampaign;
}

export async function fetchOutreachByChannel(leadId: string, channel: OutreachChannel): Promise<OutreachCampaign[]> {
  const { data, error } = await supabase
    .from('outreach_campaigns')
    .select('*')
    .eq('lead_id', leadId)
    .eq('channel_type', channel)
    .order('created_at', { ascending: false });
  if (error) throw error;
  return (data ?? []) as OutreachCampaign[];
}

export async function fetchAllOutreachByLead(leadId: string): Promise<OutreachCampaign[]> {
  const { data, error } = await supabase
    .from('outreach_campaigns')
    .select('*')
    .eq('lead_id', leadId)
    .order('created_at', { ascending: false });
  if (error) throw error;
  return (data ?? []) as OutreachCampaign[];
}

// ---- REVENUE FORECASTING ----
export async function fetchRevenueForecast(
  leads: Lead[],
  scoreMap: Record<string, number>,
  analytics: { pipeline_value: number; conversion_rate: number; closed_won: number } | null,
): Promise<RevenueForecast[]> {
  return generateRevenueForecast(leads, scoreMap, analytics);
}

// ---- INTERACTIONS ----
export async function fetchInteractions(leadId: string): Promise<SalesInteraction[]> {
  const { data, error } = await supabase.from('sales_interactions').select('*').eq('lead_id', leadId).order('interaction_date', { ascending: false });
  if (error) throw error;
  return (data ?? []) as SalesInteraction[];
}

export async function logInteraction(
  lead: Lead,
  transcript: string,
  type: SalesInteraction['interaction_type'],
  duration: number,
): Promise<SalesInteraction> {
  let summary: { summary: string; key_points: { point: string }[]; action_items: ActionItem[] };

  if (await checkHealth()) {
    try {
      const conv = await apiAnalyseMeeting(transcript, lead);
      summary = {
        summary: conv.summary,
        key_points: conv.key_discussion_points.map((p) => ({ point: p })),
        action_items: conv.action_items.map((a) => ({ owner: 'Sales Rep', action: a, due: conv.next_steps })),
      };
    } catch {
      summary = summarizeConversation(transcript, lead);
    }
  } else {
    summary = summarizeConversation(transcript, lead);
  }

  const { data, error } = await supabase
    .from('sales_interactions')
    .insert({ lead_id: lead.id, transcript, interaction_type: type, duration_minutes: duration, ...summary })
    .select()
    .single();
  if (error) throw error;
  return data as SalesInteraction;
}

// ---- CRM SYNC LOGS ----
export async function fetchSyncLogs(leadId: string): Promise<CrmSyncLog[]> {
  const { data, error } = await supabase.from('crm_sync_logs').select('*').eq('lead_id', leadId).order('timestamp', { ascending: false });
  if (error) throw error;
  return (data ?? []) as CrmSyncLog[];
}

export async function syncToCrm(leadId: string, platform: string, syncType: string, details: string): Promise<CrmSyncLog> {
  const { data, error } = await supabase
    .from('crm_sync_logs')
    .insert({ lead_id: leadId, crm_platform: platform, sync_type: syncType, details, sync_status: 'Synced' })
    .select()
    .single();
  if (error) throw error;
  return data as CrmSyncLog;
}

export async function fetchAllSyncLogs(): Promise<CrmSyncLog[]> {
  const { data, error } = await supabase.from('crm_sync_logs').select('*').order('timestamp', { ascending: false }).limit(100);
  if (error) throw error;
  return (data ?? []) as CrmSyncLog[];
}

// AI-driven batch sync: analyzes every lead, determines what to sync,
// and writes a smart log entry with AI-generated summary.
export async function aiSyncAllLeadsToCrm(leads: Lead[], platform = 'Salesforce'): Promise<CrmSyncLog[]> {
  const logs: CrmSyncLog[] = [];
  for (const lead of leads) {
    let score: { lead_score: number; qualification_label: string } | null = null;
    try {
      const scores = await fetchScores(lead.id);
      if (scores.length > 0) {
        score = { lead_score: scores[0].lead_score, qualification_label: scores[0].qualification_label };
      }
    } catch {
      // no score available — sync anyway with null score
    }

    const activity = generateCrmSyncActivity(lead, score);
    const { data, error } = await supabase
      .from('crm_sync_logs')
      .insert({
        lead_id: lead.id,
        crm_platform: platform,
        sync_type: activity.sync_type,
        details: `${activity.summary}\n\nChanges:\n${activity.changes.map((c) => `• ${c}`).join('\n')}`,
        sync_status: 'Synced',
      })
      .select()
      .single();
    if (!error && data) logs.push(data as CrmSyncLog);
  }
  return logs;
}

// ---- FOLLOW-UPS ----
export async function fetchFollowUps(leadId: string): Promise<FollowUpRecommendation[]> {
  const { data, error } = await supabase.from('follow_up_recommendations').select('*').eq('lead_id', leadId).order('generated_at', { ascending: false });
  if (error) throw error;
  return (data ?? []) as FollowUpRecommendation[];
}

export async function generateFollowUpsApi(lead: Lead, score: { lead_score: number } | null): Promise<FollowUpRecommendation[]> {
  const recs = generateFollowupRecommendations(lead, score);
  const rows = recs.map((r) => ({ lead_id: lead.id, ...r }));
  const { data, error } = await supabase.from('follow_up_recommendations').insert(rows).select();
  if (error) throw error;
  return (data ?? []) as FollowUpRecommendation[];
}

// ---- ANALYTICS ----
export async function fetchAnalytics(): Promise<SalesAnalytics[]> {
  const { data, error } = await supabase.from('sales_analytics').select('*').order('generated_at', { ascending: false });
  if (error) throw error;
  return (data ?? []) as SalesAnalytics[];
}

// ---- AGENTIC PIPELINE ----
export async function runIntelligence(lead: Lead) {
  let insightRow: Omit<CompanyInsight, 'id' | 'lead_id' | 'generated_at'>;
  let scoreRow: Omit<LeadScore, 'id' | 'lead_id' | 'generated_at'>;
  let outreachRow: Omit<OutreachCampaign, 'id' | 'lead_id' | 'created_at' | 'campaign_status'>;
  let followupRecs: { recommendation: string; priority: 'High' | 'Medium' | 'Low'; recommended_action: string; timing: string }[];

  if (await checkHealth()) {
    try {
      const result = await apiFullPipeline(lead);
      insightRow = {
        business_needs: result.insight.business_needs,
        opportunities: result.insight.opportunities,
        industry_analysis: result.insight.industry_analysis,
        key_signals: [{ signal: 'Qualification Score', points: result.insight.qualification_score, detail: result.insight.qualification_reasoning }],
      };
      const label = result.score.priority_level === 'Hot' ? 'Highly Qualified' : result.score.priority_level === 'Warm' ? 'Qualified' : 'Cold';
      scoreRow = {
        lead_score: result.score.lead_score,
        conversion_probability: Math.round(result.score.conversion_probability * 100),
        scoring_factors: [{ factor: 'AI Assessment', points: result.score.lead_score, note: result.score.scoring_factors }],
        qualification_label: label,
      };
      outreachRow = {
        email_subject: result.email.subject,
        email_content: result.email.body,
        outreach_strategy: {
          followUpTiming: result.email.follow_up_timing,
          channel: result.email.channel_recommendation,
          priority: lead.priority,
        },
      };
      followupRecs = result.followup
        ? [{
            recommendation: result.followup.follow_up_message,
            priority: result.followup.deal_risk === 'High' ? 'High' : result.followup.deal_risk === 'Medium' ? 'Medium' : 'Low',
            recommended_action: result.followup.timing,
            timing: result.followup.channel,
          }]
        : generateFollowupRecommendations(lead, scoreRow);
    } catch {
      const { insight, score, outreach, followups } = fallbackPipeline(lead);
      insightRow = insight;
      scoreRow = score;
      outreachRow = outreach;
      followupRecs = followups;
    }
  } else {
    const { insight, score, outreach, followups } = fallbackPipeline(lead);
    insightRow = insight;
    scoreRow = score;
    outreachRow = outreach;
    followupRecs = followups;
  }

  await supabase.from('company_insights').delete().eq('lead_id', lead.id);
  await supabase.from('lead_scores').delete().eq('lead_id', lead.id);
  await supabase.from('outreach_campaigns').delete().eq('lead_id', lead.id).eq('campaign_status', 'Draft');
  await supabase.from('follow_up_recommendations').delete().eq('lead_id', lead.id);

  const { data: insightDb } = await supabase.from('company_insights').insert({ lead_id: lead.id, ...insightRow }).select().single();
  const { data: scoreDb } = await supabase.from('lead_scores').insert({ lead_id: lead.id, ...scoreRow }).select().single();
  const { data: outreachDb } = await supabase.from('outreach_campaigns').insert({ lead_id: lead.id, ...outreachRow, campaign_status: 'Draft' }).select().single();
  const followupRows = followupRecs.map((r) => ({ lead_id: lead.id, ...r }));
  const { data: followupDb } = await supabase.from('follow_up_recommendations').insert(followupRows).select();

  return {
    insight: insightDb as CompanyInsight,
    score: scoreDb as LeadScore,
    outreach: outreachDb as OutreachCampaign,
    followups: (followupDb ?? []) as FollowUpRecommendation[],
  };
}

function fallbackPipeline(lead: Lead) {
  const insight = analyzeCompany(lead);
  const score = scoreLead(lead);
  const outreach = generateOutreach(lead, insight, score);
  const followups = generateFollowupRecommendations(lead, score);
  return { insight, score, outreach, followups };
}
