import type { Lead } from '../types';

const API_BASE = 'http://127.0.0.1:8000/api';

// Shapes returned by the FastAPI backend (models/*.py)
export interface ApiInsight {
  business_needs: string;
  opportunities: string;
  industry_analysis: string;
  qualification_score: number;
  qualification_reasoning: string;
}

export interface ApiScore {
  lead_score: number;
  conversion_probability: number;
  priority_level: 'Hot' | 'Warm' | 'Cold';
  scoring_factors: string;
  recommended_action: string;
}

export interface ApiEmail {
  subject: string;
  body: string;
  follow_up_timing: string;
  channel_recommendation: string;
}

export interface ApiConversation {
  summary: string;
  key_discussion_points: string[];
  action_items: string[];
  next_steps: string;
  sentiment: 'Positive' | 'Neutral' | 'Negative';
}

export interface ApiFollowUp {
  follow_up_message: string;
  timing: string;
  channel: string;
  talking_points: string[];
  deal_risk: 'Low' | 'Medium' | 'High';
  deal_risk_reasoning: string;
}

export interface ApiFullPipeline {
  status: string;
  company: string;
  insight: ApiInsight;
  score: ApiScore;
  email: ApiEmail;
  conversation: ApiConversation | null;
  followup: ApiFollowUp | null;
}

interface LeadPayload {
  company_name: string;
  industry: string;
  contact_name: string;
  email: string;
  company_size?: string;
  annual_revenue?: string;
  location?: string;
  funding_stage?: string;
  technology_stack?: string;
}

function toPayload(lead: Lead): LeadPayload {
  return {
    company_name: lead.company_name,
    industry: lead.industry,
    contact_name: lead.contact_name,
    email: lead.email,
    company_size: lead.company_size || undefined,
    annual_revenue: lead.annual_revenue || undefined,
    location: lead.location || undefined,
    funding_stage: lead.funding_stage || undefined,
    technology_stack: lead.technology_stack.join(', ') || undefined,
  };
}

async function postJson<T>(path: string, body: unknown): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body),
  });
  if (!res.ok) {
    const text = await res.text().catch(() => '');
    throw new Error(`API ${res.status}: ${text || res.statusText}`);
  }
  return (await res.json()) as T;
}

export async function checkHealth(): Promise<boolean> {
  try {
    const res = await fetch(`${API_BASE}/health`, { method: 'GET' });
    return res.ok;
  } catch {
    return false;
  }
}

export async function analyseLead(lead: Lead): Promise<{ insight: ApiInsight; score: ApiScore }> {
  const data = await postJson<{ insight: ApiInsight; score: ApiScore }>('/analyse-lead', toPayload(lead));
  return { insight: data.insight, score: data.score };
}

export async function generateEmail(lead: Lead): Promise<ApiEmail> {
  const data = await postJson<{ email: ApiEmail }>('/generate-email', toPayload(lead));
  return data.email;
}

export async function analyseMeeting(transcript: string, lead: Lead): Promise<ApiConversation> {
  const data = await postJson<{ conversation: ApiConversation }>('/analyse-meeting', {
    transcript,
    company_name: lead.company_name,
    contact_name: lead.contact_name,
  });
  return data.conversation;
}

export async function fullPipeline(lead: Lead, transcript?: string): Promise<ApiFullPipeline> {
  return postJson<ApiFullPipeline>('/full-pipeline', { ...toPayload(lead), transcript: transcript || undefined });
}
