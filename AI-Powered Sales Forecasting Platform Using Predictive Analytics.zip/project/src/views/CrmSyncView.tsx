import { useEffect, useState } from 'react';
import { RefreshCw, Database, CheckCircle2, XCircle, Clock, Sparkles, Filter, ChevronDown, ChevronUp } from 'lucide-react';
import type { Lead, CrmSyncLog } from '../types';
import { fetchLeads, fetchAllSyncLogs, aiSyncAllLeadsToCrm } from '../lib/api';
import { Section, StatusBadge, LoadingSpinner, EmptyState, ErrorState, Badge } from '../components/ui';

export function CrmSyncView() {
  const [leads, setLeads] = useState<Lead[]>([]);
  const [logs, setLogs] = useState<CrmSyncLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [syncing, setSyncing] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [platform, setPlatform] = useState('Salesforce');
  const [expanded, setExpanded] = useState<string | null>(null);
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [syncResult, setSyncResult] = useState<{ synced: number; failed: number } | null>(null);

  useEffect(() => {
    load();
  }, []);

  async function load() {
    try {
      setLoading(true);
      const [l, s] = await Promise.all([fetchLeads(), fetchAllSyncLogs()]);
      setLeads(l);
      setLogs(s);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load');
    } finally {
      setLoading(false);
    }
  }

  async function handleAiSync() {
    try {
      setSyncing(true);
      setError(null);
      setSyncResult(null);
      const results = await aiSyncAllLeadsToCrm(leads, platform);
      setSyncResult({ synced: results.length, failed: leads.length - results.length });
      const s = await fetchAllSyncLogs();
      setLogs(s);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Sync failed');
    } finally {
      setSyncing(false);
    }
  }

  const filteredLogs = statusFilter === 'all' ? logs : logs.filter((l) => l.sync_status === statusFilter);

  const stats = {
    total: logs.length,
    synced: logs.filter((l) => l.sync_status === 'Synced').length,
    pending: logs.filter((l) => l.sync_status === 'Pending').length,
    failed: logs.filter((l) => l.sync_status === 'Failed').length,
  };

  const leadMap = new Map(leads.map((l) => [l.id, l]));

  if (loading) return <LoadingSpinner label="Loading CRM sync activity..." />;

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="card p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <span className="w-10 h-10 rounded-lg bg-primary-500/10 flex items-center justify-center">
              <Database className="w-5 h-5 text-primary-400" />
            </span>
            <div>
              <h2 className="text-lg font-bold text-white">CRM Sync Activity</h2>
              <p className="text-sm text-neutral-400">AI-driven sync keeps your CRM enriched with signal scores, status changes, and company data</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <select
              value={platform}
              onChange={(e) => setPlatform(e.target.value)}
              className="text-sm bg-neutral-900 border border-neutral-700 rounded-lg px-3 py-2 text-neutral-200 focus:outline-none focus:border-primary-500"
            >
              <option>Salesforce</option>
              <option>HubSpot</option>
              <option>Pipedrive</option>
              <option>Zoho</option>
            </select>
            <button onClick={handleAiSync} disabled={syncing || leads.length === 0} className="btn-primary text-sm">
              {syncing ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
              {syncing ? 'Syncing...' : 'AI Sync All'}
            </button>
          </div>
        </div>

        {syncResult && (
          <div className="mt-4 flex items-center gap-3 p-3 rounded-lg bg-accent-500/10 border border-accent-500/20">
            <CheckCircle2 className="w-5 h-5 text-accent-400" />
            <p className="text-sm text-accent-300">
              AI sync complete: {syncResult.synced} leads synced to {platform}
              {syncResult.failed > 0 && `, ${syncResult.failed} failed`}
            </p>
          </div>
        )}
      </div>

      {/* Stats cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        <SyncStatCard icon={<Database className="w-5 h-5" />} label="Total Syncs" value={stats.total} color="primary" />
        <SyncStatCard icon={<CheckCircle2 className="w-5 h-5" />} label="Synced" value={stats.synced} color="accent" />
        <SyncStatCard icon={<Clock className="w-5 h-5" />} label="Pending" value={stats.pending} color="warning" />
        <SyncStatCard icon={<XCircle className="w-5 h-5" />} label="Failed" value={stats.failed} color="error" />
      </div>

      {error && <ErrorState message={error} />}

      {/* Sync log */}
      <Section
        title="Sync Activity Log"
        icon={<RefreshCw className="w-4 h-4" />}
        action={
          <div className="flex items-center gap-2">
            <Filter className="w-3.5 h-3.5 text-neutral-500" />
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="text-xs bg-neutral-900 border border-neutral-700 rounded-lg px-2 py-1.5 text-neutral-200 focus:outline-none focus:border-primary-500"
            >
              <option value="all">All Status</option>
              <option value="Synced">Synced</option>
              <option value="Pending">Pending</option>
              <option value="Failed">Failed</option>
            </select>
          </div>
        }
      >
        {syncing ? (
          <LoadingSpinner label="Running AI sync across all leads..." />
        ) : filteredLogs.length === 0 ? (
          <EmptyState title="No sync activity" description="Click AI Sync All to push enriched lead data to your CRM." icon={<Database className="w-8 h-8" />} />
        ) : (
          <div className="space-y-3">
            {filteredLogs.map((log) => {
              const lead = leadMap.get(log.lead_id);
              const isExpanded = expanded === log.id;
              const lines = log.details.split('\n');
              const summary = lines[0] || log.details;
              const changes = lines.slice(1).filter((l) => l.startsWith('•'));

              return (
                <div key={log.id} className="p-4 bg-neutral-950 border border-neutral-800 rounded-lg hover:border-neutral-700 transition-colors">
                  <div className="flex items-start justify-between gap-3">
                    <div className="flex items-start gap-3 min-w-0 flex-1">
                      <span className={`w-8 h-8 rounded-lg flex items-center justify-center shrink-0 ${
                        log.sync_status === 'Synced' ? 'bg-accent-500/10 text-accent-400' :
                        log.sync_status === 'Pending' ? 'bg-warning-500/10 text-warning-400' :
                        'bg-error-500/10 text-error-400'
                      }`}>
                        {log.sync_status === 'Synced' ? <CheckCircle2 className="w-4 h-4" /> :
                         log.sync_status === 'Pending' ? <Clock className="w-4 h-4" /> :
                         <XCircle className="w-4 h-4" />}
                      </span>
                      <div className="min-w-0 flex-1">
                        <div className="flex items-center gap-2 flex-wrap">
                          <p className="text-sm font-medium text-neutral-100">{lead?.company_name ?? 'Unknown'}</p>
                          <StatusBadge status={log.sync_status} />
                          <Badge variant="neutral">{log.sync_type}</Badge>
                          <Badge variant="primary">{log.crm_platform}</Badge>
                        </div>
                        <p className="text-sm text-neutral-400 mt-1">{summary}</p>
                        {changes.length > 0 && (
                          <div className="mt-2">
                            <button
                              onClick={() => setExpanded(isExpanded ? null : log.id)}
                              className="flex items-center gap-1 text-xs text-primary-400 hover:text-primary-300"
                            >
                              {isExpanded ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                              {isExpanded ? 'Hide changes' : `${changes.length} changes`}
                            </button>
                            {isExpanded && (
                              <div className="mt-2 space-y-1">
                                {changes.map((c, i) => (
                                  <p key={i} className="text-xs text-neutral-400 pl-4">{c}</p>
                                ))}
                              </div>
                            )}
                          </div>
                        )}
                      </div>
                    </div>
                    <span className="text-xs text-neutral-500 shrink-0 whitespace-nowrap">
                      {new Date(log.timestamp).toLocaleString()}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </Section>
    </div>
  );
}

function SyncStatCard({ icon, label, value, color }: { icon: React.ReactNode; label: string; value: number; color: 'primary' | 'accent' | 'warning' | 'error' }) {
  const colors: Record<string, string> = {
    primary: 'text-primary-400 bg-primary-500/10',
    accent: 'text-accent-400 bg-accent-500/10',
    warning: 'text-warning-400 bg-warning-500/10',
    error: 'text-error-400 bg-error-500/10',
  };
  return (
    <div className="card card-hover p-4">
      <div className="flex items-center gap-3">
        <span className={`w-9 h-9 rounded-lg flex items-center justify-center ${colors[color]}`}>{icon}</span>
        <div>
          <p className="text-xl font-bold text-white">{value}</p>
          <p className="text-xs text-neutral-400">{label}</p>
        </div>
      </div>
    </div>
  );
}
