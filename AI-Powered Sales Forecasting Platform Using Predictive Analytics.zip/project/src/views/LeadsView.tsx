import { useEffect, useState } from 'react';
import { Plus, Search, Building2, Mail, Phone, Globe, MapPin, Users, DollarSign, Cpu, Trash2, Zap, Target, TrendingUp, Sparkles, X } from 'lucide-react';
import type { Lead, LeadScore, CompanyInsight, FollowUpRecommendation } from '../types';
import { fetchLeads, createLead, deleteLead, fetchScores, fetchInsights, fetchFollowUps, scoreLeadApi, analyzeLeadCompany, generateFollowUpsApi, runIntelligence } from '../lib/api';
import { Section, Badge, StatusBadge, LoadingSpinner, EmptyState, ErrorState } from '../components/ui';
import { SignalGauge } from '../components/SignalGauge';

const emptyLead: Omit<Lead, 'id' | 'created_at' | 'updated_at'> = {
  company_name: '', industry: '', contact_name: '', contact_title: '', email: '', phone: '',
  website: '', location: '', company_size: '', annual_revenue: '', funding_stage: 'Seed',
  technology_stack: [], lead_status: 'New', priority: 'Medium', notes: '',
};

export function LeadsView({ selectedLeadId, onSelectLead }: { selectedLeadId: string | null; onSelectLead: (id: string) => void }) {
  const [leads, setLeads] = useState<Lead[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [search, setSearch] = useState('');
  const [showAdd, setShowAdd] = useState(false);
  const [newLead, setNewLead] = useState(emptyLead);
  const [techInput, setTechInput] = useState('');
  const [creating, setCreating] = useState(false);

  useEffect(() => {
    loadLeads();
  }, []);

  async function loadLeads() {
    try {
      setLoading(true);
      const data = await fetchLeads();
      setLeads(data);
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load leads');
    } finally {
      setLoading(false);
    }
  }

  async function handleCreate() {
    if (!newLead.company_name || !newLead.contact_name) return;
    try {
      setCreating(true);
      const created = await createLead(newLead);
      setLeads([created, ...leads]);
      setNewLead(emptyLead);
      setTechInput('');
      setShowAdd(false);
      onSelectLead(created.id);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to create lead');
    } finally {
      setCreating(false);
    }
  }

  async function handleDelete(id: string) {
    try {
      await deleteLead(id);
      setLeads(leads.filter((l) => l.id !== id));
      if (selectedLeadId === id) onSelectLead('');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to delete lead');
    }
  }

  function addTech() {
    if (techInput.trim() && !newLead.technology_stack.includes(techInput.trim())) {
      setNewLead({ ...newLead, technology_stack: [...newLead.technology_stack, techInput.trim()] });
      setTechInput('');
    }
  }

  const filtered = leads.filter((l) => {
    const q = search.toLowerCase();
    return l.company_name.toLowerCase().includes(q) || l.contact_name.toLowerCase().includes(q) || l.industry.toLowerCase().includes(q);
  });

  const selectedLead = leads.find((l) => l.id === selectedLeadId) || null;

  return (
    <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 animate-fade-in">
      {/* Lead list */}
      <div className="lg:col-span-5 xl:col-span-4">
        <Section
          title="Lead Pipeline"
          icon={<Target className="w-4 h-4" />}
          action={
            <button onClick={() => setShowAdd(!showAdd)} className="btn-ghost text-xs">
              <Plus className="w-4 h-4" /> Add
            </button>
          }
        >
          <div className="mb-4 relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-500" />
            <input
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              placeholder="Search leads..."
              className="input pl-9"
            />
          </div>

          {showAdd && (
            <div className="mb-4 p-4 bg-neutral-950 border border-neutral-800 rounded-lg space-y-3 animate-slide-up">
              <div className="flex items-center justify-between">
                <h4 className="text-sm font-medium text-neutral-200">New Lead</h4>
                <button onClick={() => setShowAdd(false)} className="btn-ghost p-1"><X className="w-4 h-4" /></button>
              </div>
              <div className="grid grid-cols-2 gap-2">
                <input className="input col-span-2" placeholder="Company name *" value={newLead.company_name} onChange={(e) => setNewLead({ ...newLead, company_name: e.target.value })} />
                <input className="input" placeholder="Industry" value={newLead.industry} onChange={(e) => setNewLead({ ...newLead, industry: e.target.value })} />
                <input className="input" placeholder="Contact name *" value={newLead.contact_name} onChange={(e) => setNewLead({ ...newLead, contact_name: e.target.value })} />
                <input className="input" placeholder="Title" value={newLead.contact_title} onChange={(e) => setNewLead({ ...newLead, contact_title: e.target.value })} />
                <input className="input" placeholder="Email" value={newLead.email} onChange={(e) => setNewLead({ ...newLead, email: e.target.value })} />
                <input className="input" placeholder="Company size" value={newLead.company_size} onChange={(e) => setNewLead({ ...newLead, company_size: e.target.value })} />
                <input className="input" placeholder="Annual revenue" value={newLead.annual_revenue} onChange={(e) => setNewLead({ ...newLead, annual_revenue: e.target.value })} />
                <select className="input" value={newLead.funding_stage} onChange={(e) => setNewLead({ ...newLead, funding_stage: e.target.value })}>
                  {['Seed', 'Series A', 'Series B', 'Series C', 'Series D'].map((s) => <option key={s} value={s}>{s}</option>)}
                </select>
                <select className="input" value={newLead.priority} onChange={(e) => setNewLead({ ...newLead, priority: e.target.value as 'High' | 'Medium' | 'Low' })}>
                  {['High', 'Medium', 'Low'].map((s) => <option key={s} value={s}>{s}</option>)}
                </select>
              </div>
              <div className="flex gap-2">
                <input
                  className="input"
                  placeholder="Add tech (press Enter)"
                  value={techInput}
                  onChange={(e) => setTechInput(e.target.value)}
                  onKeyDown={(e) => { if (e.key === 'Enter') { e.preventDefault(); addTech(); } }}
                />
                <button onClick={addTech} className="btn-secondary">Add</button>
              </div>
              {newLead.technology_stack.length > 0 && (
                <div className="flex flex-wrap gap-1.5">
                  {newLead.technology_stack.map((t) => (
                    <Badge key={t} variant="primary">{t}</Badge>
                  ))}
                </div>
              )}
              <button onClick={handleCreate} disabled={creating || !newLead.company_name || !newLead.contact_name} className="btn-primary w-full">
                {creating ? 'Creating...' : 'Create Lead'}
              </button>
            </div>
          )}

          {loading ? (
            <LoadingSpinner label="Loading leads..." />
          ) : error ? (
            <ErrorState message={error} />
          ) : filtered.length === 0 ? (
            <EmptyState title="No leads yet" description="Add your first lead to start the AI intelligence pipeline." icon={<Target className="w-8 h-8" />} />
          ) : (
            <div className="space-y-2 max-h-[calc(100vh-280px)] overflow-y-auto pr-1">
              {filtered.map((lead) => (
                <button
                  key={lead.id}
                  onClick={() => onSelectLead(lead.id)}
                  className={`w-full text-left p-3.5 rounded-lg border transition-all duration-200 ${
                    selectedLeadId === lead.id
                      ? 'bg-primary-500/10 border-primary-500/40'
                      : 'bg-neutral-950 border-neutral-800 hover:border-neutral-700'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0 flex-1">
                      <div className="flex items-center gap-2">
                        <Building2 className="w-3.5 h-3.5 text-neutral-500 shrink-0" />
                        <span className="text-sm font-medium text-neutral-100 truncate">{lead.company_name}</span>
                      </div>
                      <p className="text-xs text-neutral-500 mt-1 truncate">{lead.contact_name} · {lead.contact_title}</p>
                      <div className="flex items-center gap-1.5 mt-2">
                        <StatusBadge status={lead.lead_status} />
                        <StatusBadge status={lead.priority} />
                      </div>
                    </div>
                    <span
                      role="button"
                      tabIndex={0}
                      onClick={(e) => { e.stopPropagation(); handleDelete(lead.id); }}
                      onKeyDown={(e) => { if (e.key === 'Enter') { e.stopPropagation(); handleDelete(lead.id); } }}
                      className="text-neutral-600 hover:text-error-400 p-1 rounded transition-colors cursor-pointer"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </span>
                  </div>
                </button>
              ))}
            </div>
          )}
        </Section>
      </div>

      {/* Lead detail / intelligence */}
      <div className="lg:col-span-7 xl:col-span-8">
        {selectedLead ? (
          <LeadIntelligencePanel lead={selectedLead} />
        ) : (
          <div className="card flex flex-col items-center justify-center py-20 text-center">
            <Sparkles className="w-10 h-10 text-neutral-700 mb-3" />
            <h3 className="text-base font-medium text-neutral-300">Select a lead to view AI intelligence</h3>
            <p className="text-sm text-neutral-500 mt-1 max-w-md">
              Choose a lead from the list to see company analysis, signal scoring, outreach generation, and follow-up recommendations.
            </p>
          </div>
        )}
      </div>
    </div>
  );
}

function LeadIntelligencePanel({ lead }: { lead: Lead }) {
  const [scores, setScores] = useState<LeadScore[]>([]);
  const [insights, setInsights] = useState<CompanyInsight[]>([]);
  const [followups, setFollowups] = useState<FollowUpRecommendation[]>([]);
  const [loading, setLoading] = useState(true);
  const [running, setRunning] = useState(false);
  const [scoring, setScoring] = useState(false);
  const [analyzing, setAnalyzing] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadAll();
  }, [lead.id]);

  async function loadAll() {
    try {
      setLoading(true);
      const [s, i, f] = await Promise.all([fetchScores(lead.id), fetchInsights(lead.id), fetchFollowUps(lead.id)]);
      setScores(s);
      setInsights(i);
      setFollowups(f);
      setError(null);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load intelligence');
    } finally {
      setLoading(false);
    }
  }

  async function handleRunIntelligence() {
    try {
      setRunning(true);
      await runIntelligence(lead);
      await loadAll();
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Intelligence run failed');
    } finally {
      setRunning(false);
    }
  }

  async function handleScore() {
    try {
      setScoring(true);
      await scoreLeadApi(lead);
      const s = await fetchScores(lead.id);
      setScores(s);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Scoring failed');
    } finally {
      setScoring(false);
    }
  }

  async function handleAnalyze() {
    try {
      setAnalyzing(true);
      await analyzeLeadCompany(lead);
      const i = await fetchInsights(lead.id);
      setInsights(i);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Analysis failed');
    } finally {
      setAnalyzing(false);
    }
  }

  const latestScore = scores[0];
  const latestInsight = insights[0];

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Lead header */}
      <div className="card p-5">
        <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <h2 className="text-xl font-bold text-white">{lead.company_name}</h2>
              <StatusBadge status={lead.lead_status} />
              <StatusBadge status={lead.priority} />
            </div>
            <p className="text-sm text-neutral-400">{lead.industry} · {lead.funding_stage} · {lead.company_size}</p>
          </div>
          <div className="flex flex-wrap gap-2">
            <button onClick={handleRunIntelligence} disabled={running} className="btn-primary">
              <Zap className="w-4 h-4" /> {running ? 'Running...' : 'Run Full Intelligence'}
            </button>
          </div>
        </div>

        <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-4 pt-4 border-t border-neutral-800">
          <InfoChip icon={<Mail className="w-3.5 h-3.5" />} label="Email" value={lead.email || '—'} />
          <InfoChip icon={<Phone className="w-3.5 h-3.5" />} label="Phone" value={lead.phone || '—'} />
          <InfoChip icon={<Globe className="w-3.5 h-3.5" />} label="Website" value={lead.website || '—'} />
          <InfoChip icon={<MapPin className="w-3.5 h-3.5" />} label="Location" value={lead.location || '—'} />
          <InfoChip icon={<Users className="w-3.5 h-3.5" />} label="Size" value={lead.company_size || '—'} />
          <InfoChip icon={<DollarSign className="w-3.5 h-3.5" />} label="Revenue" value={lead.annual_revenue || '—'} />
          <InfoChip icon={<TrendingUp className="w-3.5 h-3.5" />} label="Funding" value={lead.funding_stage || '—'} />
          <InfoChip icon={<Cpu className="w-3.5 h-3.5" />} label="Stack" value={lead.technology_stack.length > 0 ? `${lead.technology_stack.length} techs` : '—'} />
        </div>

        {lead.technology_stack.length > 0 && (
          <div className="flex flex-wrap gap-1.5 mt-3">
            {lead.technology_stack.map((t) => <Badge key={t} variant="primary">{t}</Badge>)}
          </div>
        )}
      </div>

      {error && <ErrorState message={error} />}

      {loading ? (
        <LoadingSpinner label="Loading intelligence..." />
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          {/* Signal Score */}
          <Section
            title="Signal Score"
            icon={<Target className="w-4 h-4" />}
            action={
              <button onClick={handleScore} disabled={scoring} className="btn-ghost text-xs">
                {scoring ? 'Scoring...' : 'Re-score'}
              </button>
            }
          >
            {latestScore ? (
              <div className="flex flex-col items-center">
                <SignalGauge score={latestScore.lead_score} conversionProbability={latestScore.conversion_probability} />
                <Badge variant={latestScore.lead_score >= 80 ? 'success' : latestScore.lead_score >= 60 ? 'warning' : 'error'}>
                  {latestScore.qualification_label}
                </Badge>
                <div className="w-full mt-5 space-y-2">
                  {latestScore.scoring_factors.map((f, i) => (
                    <div key={i} className="flex items-center justify-between p-2.5 bg-neutral-950 rounded-lg border border-neutral-800">
                      <div>
                        <p className="text-sm text-neutral-200">{f.factor}</p>
                        {f.note && <p className="text-xs text-neutral-500 mt-0.5">{f.note}</p>}
                      </div>
                      <span className="text-sm font-semibold text-accent-400">+{f.points}</span>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <EmptyState title="No score yet" description="Run scoring to get an explainable 0–100 signal score." icon={<Target className="w-8 h-8" />} />
            )}
          </Section>

          {/* Company Insight */}
          <Section
            title="Company Intelligence"
            icon={<Sparkles className="w-4 h-4" />}
            action={
              <button onClick={handleAnalyze} disabled={analyzing} className="btn-ghost text-xs">
                {analyzing ? 'Analyzing...' : 'Re-analyze'}
              </button>
            }
          >
            {latestInsight ? (
              <div className="space-y-4">
                <InsightBlock label="Business Needs" content={latestInsight.business_needs} />
                <InsightBlock label="Opportunities" content={latestInsight.opportunities} />
                <InsightBlock label="Industry Analysis" content={latestInsight.industry_analysis} />
                {latestInsight.key_signals.length > 0 && (
                  <div>
                    <p className="text-xs font-semibold text-neutral-400 uppercase tracking-wide mb-2">Key Signals</p>
                    <div className="space-y-1.5">
                      {latestInsight.key_signals.map((s, i) => (
                        <div key={i} className="flex items-center justify-between p-2 bg-neutral-950 rounded-lg border border-neutral-800">
                          <div>
                            <p className="text-sm text-neutral-200">{s.signal}</p>
                            <p className="text-xs text-neutral-500">{s.detail}</p>
                          </div>
                          <span className="text-sm font-semibold text-accent-400">+{s.points}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            ) : (
              <EmptyState title="No analysis yet" description="Run company analysis to generate AI insights." icon={<Sparkles className="w-8 h-8" />} />
            )}
          </Section>

          {/* Follow-up Recommendations */}
          <Section title="Follow-Up Recommendations" icon={<Zap className="w-4 h-4" />} className="md:col-span-2">
            {followups.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {followups.map((f) => (
                  <div key={f.id} className="p-4 bg-neutral-950 rounded-lg border border-neutral-800">
                    <div className="flex items-center justify-between mb-2">
                      <StatusBadge status={f.priority} />
                      <span className="text-xs text-neutral-500">{f.timing}</span>
                    </div>
                    <p className="text-sm text-neutral-200">{f.recommendation}</p>
                    <p className="text-xs text-primary-400 mt-2 font-medium">→ {f.recommended_action}</p>
                  </div>
                ))}
              </div>
            ) : (
              <EmptyState title="No recommendations yet" description="Run full intelligence to get AI follow-up recommendations." icon={<Zap className="w-8 h-8" />} />
            )}
          </Section>
        </div>
      )}
    </div>
  );
}

function InfoChip({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="flex items-center gap-2">
      <span className="text-neutral-500">{icon}</span>
      <div className="min-w-0">
        <p className="text-xs text-neutral-500">{label}</p>
        <p className="text-sm text-neutral-200 truncate">{value}</p>
      </div>
    </div>
  );
}

function InsightBlock({ label, content }: { label: string; content: string }) {
  return (
    <div>
      <p className="text-xs font-semibold text-neutral-400 uppercase tracking-wide mb-1.5">{label}</p>
      <p className="text-sm text-neutral-300 leading-relaxed">{content}</p>
    </div>
  );
}
