import { useEffect, useState } from 'react';
import {
  Mail, Send, Copy, Check, Sparkles, Target, ChevronDown, ChevronUp,
  Zap, TrendingUp, Clock, MessageSquare, RefreshCw, Save, Inbox,
  Linkedin, Phone, Shield, AlertCircle,
} from 'lucide-react';
import type { Lead, OutreachCampaign, LeadScore, CompanyInsight, OutreachChannel, ObjectionResponse } from '../types';
import {
  fetchLeads, fetchOutreach, generateOutreachApi, updateOutreachStatus, updateOutreachContent,
  fetchScores, fetchInsights, scoreLeadApi,
  generateLinkedInOutreachApi, generateCallScriptApi, generateObjectionHandlingApi,
  fetchOutreachByChannel,
} from '../lib/api';
import { Section, StatusBadge, LoadingSpinner, EmptyState, ErrorState, Badge } from '../components/ui';
import { SignalGauge } from '../components/SignalGauge';

const CHANNEL_TABS: { id: OutreachChannel; label: string; icon: React.ReactNode }[] = [
  { id: 'email', label: 'Cold Email', icon: <Mail className="w-4 h-4" /> },
  { id: 'linkedin', label: 'LinkedIn InMail', icon: <Linkedin className="w-4 h-4" /> },
  { id: 'call_script', label: 'Call Script', icon: <Phone className="w-4 h-4" /> },
  { id: 'objection_handling', label: 'Objections', icon: <Shield className="w-4 h-4" /> },
];

export function OutreachView() {
  const [leads, setLeads] = useState<Lead[]>([]);
  const [selectedLeadId, setSelectedLeadId] = useState<string | null>(null);
  const [activeChannel, setActiveChannel] = useState<OutreachChannel>('email');
  const [campaigns, setCampaigns] = useState<OutreachCampaign[]>([]);
  const [scores, setScores] = useState<LeadScore[]>([]);
  const [insights, setInsights] = useState<CompanyInsight[]>([]);
  const [loading, setLoading] = useState(true);
  const [generating, setGenerating] = useState(false);
  const [scoring, setScoring] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [copied, setCopied] = useState<string | null>(null);
  const [expanded, setExpanded] = useState<string | null>(null);

  const [editSubject, setEditSubject] = useState('');
  const [editBody, setEditBody] = useState('');
  const [dirty, setDirty] = useState(false);
  const [saving, setSaving] = useState(false);
  const [sending, setSending] = useState(false);
  const [toast, setToast] = useState<string | null>(null);

  const [sentExpanded, setSentExpanded] = useState<string | null>(null);

  useEffect(() => { loadLeads(); }, []);

  useEffect(() => {
    if (selectedLeadId) loadChannel(selectedLeadId, activeChannel);
  }, [selectedLeadId, activeChannel]);

  async function loadLeads() {
    try {
      setLoading(true);
      const data = await fetchLeads();
      setLeads(data);
      if (data.length > 0) setSelectedLeadId(data[0].id);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load leads');
    } finally {
      setLoading(false);
    }
  }

  async function loadChannel(leadId: string, channel: OutreachChannel) {
    try {
      const [c, s, i] = await Promise.all([
        channel === 'email' ? fetchOutreach(leadId) : fetchOutreachByChannel(leadId, channel),
        fetchScores(leadId),
        fetchInsights(leadId),
      ]);
      setCampaigns(c);
      setScores(s);
      setInsights(i);
      setError(null);
      if (c.length > 0) {
        setEditSubject(c[0].email_subject);
        setEditBody(c[0].email_content);
      } else {
        setEditSubject('');
        setEditBody('');
      }
      setDirty(false);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load');
    }
  }

  async function handleGenerate() {
    if (!selectedLeadId) return;
    const lead = leads.find((l) => l.id === selectedLeadId);
    if (!lead) return;
    try {
      setGenerating(true);
      const [s, i] = await Promise.all([fetchScores(lead.id), fetchInsights(lead.id)]);
      const score = s[0] || null;
      const insight = i[0] || null;

      switch (activeChannel) {
        case 'email':
          await generateOutreachApi(lead, insight, score);
          break;
        case 'linkedin':
          await generateLinkedInOutreachApi(lead, insight, score);
          break;
        case 'call_script':
          await generateCallScriptApi(lead, insight, score);
          break;
        case 'objection_handling':
          await generateObjectionHandlingApi(lead, score);
          break;
      }
      await loadChannel(lead.id, activeChannel);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Generation failed');
    } finally {
      setGenerating(false);
    }
  }

  async function handleScore() {
    if (!selectedLeadId) return;
    const lead = leads.find((l) => l.id === selectedLeadId);
    if (!lead) return;
    try {
      setScoring(true);
      await scoreLeadApi(lead);
      const s = await fetchScores(lead.id);
      setScores(s);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Scoring failed');
    } finally {
      setScoring(false);
    }
  }

  function handleEditSubject(val: string) { setEditSubject(val); setDirty(true); }
  function handleEditBody(val: string) { setEditBody(val); setDirty(true); }

  async function handleSave() {
    if (!latestCampaign) return;
    try {
      setSaving(true);
      await updateOutreachContent(latestCampaign.id, editSubject, editBody);
      await loadChannel(selectedLeadId!, activeChannel);
      showToast('Saved');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Save failed');
    } finally {
      setSaving(false);
    }
  }

  async function handleSend() {
    if (!latestCampaign) return;
    try {
      setSending(true);
      await updateOutreachContent(latestCampaign.id, editSubject, editBody);
      await updateOutreachStatus(latestCampaign.id, 'Sent');
      await loadChannel(selectedLeadId!, activeChannel);
      showToast('Sent');
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Send failed');
    } finally {
      setSending(false);
    }
  }

  function showToast(msg: string) { setToast(msg); setTimeout(() => setToast(null), 2500); }

  function handleCopy(id: string, content: string) {
    navigator.clipboard.writeText(content);
    setCopied(id);
    setTimeout(() => setCopied(null), 2000);
  }

  async function handleStatusChange(id: string, status: OutreachCampaign['campaign_status']) {
    try {
      await updateOutreachStatus(id, status);
      if (selectedLeadId) await loadChannel(selectedLeadId, activeChannel);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Update failed');
    }
  }

  const selectedLead = leads.find((l) => l.id === selectedLeadId);
  const latestCampaign = campaigns[0] || null;
  const latestScore = scores[0] || null;
  const latestInsight = insights[0] || null;
  const sentEmails = campaigns.filter((c) => c.campaign_status === 'Sent' || c.campaign_status === 'Opened' || c.campaign_status === 'Replied');

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header bar */}
      <div className="card p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <span className="w-10 h-10 rounded-lg bg-primary-500/10 flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-primary-400" />
            </span>
            <div>
              <h2 className="text-lg font-bold text-white">AI Outreach Generator</h2>
              <p className="text-sm text-neutral-400">Cold email, LinkedIn InMail, call scripts & objection handling</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            {selectedLead && <Badge variant="primary">{selectedLead.company_name}</Badge>}
            <button onClick={handleGenerate} disabled={generating || !selectedLeadId} className="btn-primary text-sm">
              {generating ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Sparkles className="w-4 h-4" />}
              {generating ? 'Generating...' : 'Generate'}
            </button>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Lead selector */}
        <div className="lg:col-span-3">
          <Section title="Select Lead" icon={<Target className="w-4 h-4" />}>
            {loading ? (
              <LoadingSpinner />
            ) : leads.length === 0 ? (
              <EmptyState title="No leads" description="Add leads first" icon={<Target className="w-8 h-8" />} />
            ) : (
              <div className="space-y-2 max-h-[calc(100vh-280px)] overflow-y-auto pr-1">
                {leads.map((lead) => (
                  <button
                    key={lead.id}
                    onClick={() => setSelectedLeadId(lead.id)}
                    className={`w-full text-left p-3 rounded-lg border transition-all ${
                      selectedLeadId === lead.id ? 'bg-primary-500/10 border-primary-500/40' : 'bg-neutral-950 border-neutral-800 hover:border-neutral-700'
                    }`}
                  >
                    <p className="text-sm font-medium text-neutral-100 truncate">{lead.company_name}</p>
                    <p className="text-xs text-neutral-500 mt-0.5 truncate">{lead.contact_name} · {lead.contact_title}</p>
                  </button>
                ))}
              </div>
            )}
          </Section>
        </div>

        {/* Main content */}
        <div className="lg:col-span-9 space-y-6">
          {error && <ErrorState message={error} />}

          {/* Channel tabs */}
          <div className="flex items-center gap-1 overflow-x-auto border-b border-neutral-800 pb-px">
            {CHANNEL_TABS.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveChannel(tab.id)}
                className={`flex items-center gap-2 px-4 py-2.5 text-sm font-medium border-b-2 transition-all whitespace-nowrap ${
                  activeChannel === tab.id
                    ? 'border-primary-500 text-white'
                    : 'border-transparent text-neutral-500 hover:text-neutral-300'
                }`}
              >
                {tab.icon}
                {tab.label}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 xl:grid-cols-3 gap-6">
            {/* Panel 1: Channel content */}
            <Section
              title={CHANNEL_TABS.find((t) => t.id === activeChannel)?.label || 'Outreach'}
              icon={CHANNEL_TABS.find((t) => t.id === activeChannel)?.icon || <Mail className="w-4 h-4" />}
              action={
                <button onClick={handleGenerate} disabled={generating || !selectedLeadId} className="btn-ghost text-xs">
                  {generating ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Sparkles className="w-3.5 h-3.5" />}
                  {generating ? '...' : 'Generate'}
                </button>
              }
            >
              {generating ? (
                <LoadingSpinner label="Generating..." />
              ) : latestCampaign ? (
                <ChannelContent
                  campaign={latestCampaign}
                  channel={activeChannel}
                  editSubject={editSubject}
                  editBody={editBody}
                  onEditSubject={handleEditSubject}
                  onEditBody={handleEditBody}
                  copied={copied}
                  onCopy={handleCopy}
                  dirty={dirty}
                  saving={saving}
                  sending={sending}
                  onSave={handleSave}
                  onSend={handleSend}
                  onStatusChange={handleStatusChange}
                  toast={toast}
                />
              ) : (
                <EmptyState
                  title={`No ${CHANNEL_TABS.find((t) => t.id === activeChannel)?.label || 'content'} yet`}
                  description="Click Generate to create AI-powered outreach content."
                  icon={CHANNEL_TABS.find((t) => t.id === activeChannel)?.icon || <Mail className="w-8 h-8" />}
                />
              )}
            </Section>

            {/* Panel 2: Lead Score */}
            <Section
              title="Lead Score"
              icon={<Target className="w-4 h-4" />}
              action={
                <button onClick={handleScore} disabled={scoring || !selectedLeadId} className="btn-ghost text-xs">
                  {scoring ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Zap className="w-3.5 h-3.5" />}
                  {scoring ? '...' : 'Re-score'}
                </button>
              }
            >
              {scoring ? (
                <LoadingSpinner label="Scoring..." />
              ) : latestScore ? (
                <div className="flex flex-col items-center">
                  <SignalGauge score={latestScore.lead_score} conversionProbability={latestScore.conversion_probability} />
                  <Badge variant={latestScore.lead_score >= 80 ? 'success' : latestScore.lead_score >= 60 ? 'warning' : 'error'}>
                    {latestScore.qualification_label}
                  </Badge>
                  <div className="w-full mt-4 space-y-2">
                    {latestScore.scoring_factors.map((f, i) => (
                      <div key={i} className="flex items-center justify-between p-2 bg-neutral-950 rounded-lg border border-neutral-800">
                        <div className="min-w-0">
                          <p className="text-xs text-neutral-200 truncate">{f.factor}</p>
                          {f.note && <p className="text-xs text-neutral-500 mt-0.5 truncate">{f.note}</p>}
                        </div>
                        <span className="text-sm font-semibold text-accent-400 shrink-0">+{f.points}</span>
                      </div>
                    ))}
                  </div>
                </div>
              ) : (
                <EmptyState title="No score yet" description="Run scoring to get an explainable 0–100 signal score." icon={<Target className="w-8 h-8" />} />
              )}
            </Section>

            {/* Panel 3: Outreach Strategy */}
            <Section title="Outreach Strategy" icon={<TrendingUp className="w-4 h-4" />}>
              {latestCampaign && latestCampaign.outreach_strategy && Object.keys(latestCampaign.outreach_strategy).length > 0 ? (
                <div className="space-y-3">
                  <StrategyRow icon={<Clock className="w-4 h-4" />} label="Follow-up Timing" value={latestCampaign.outreach_strategy.followUpTiming || latestCampaign.outreach_strategy.timing || '—'} />
                  <StrategyRow icon={<MessageSquare className="w-4 h-4" />} label="Channel" value={latestCampaign.outreach_strategy.channel || '—'} />
                  <StrategyRow icon={<Zap className="w-4 h-4" />} label="Priority" value={latestCampaign.outreach_strategy.priority || latestCampaign.outreach_strategy.contentStrategy || '—'} />

                  {latestInsight && (
                    <div className="pt-3 mt-3 border-t border-neutral-800">
                      <p className="text-xs font-semibold text-neutral-400 uppercase tracking-wide mb-2">Key Signals</p>
                      <div className="space-y-1.5">
                        {latestInsight.key_signals.slice(0, 3).map((s, i) => (
                          <div key={i} className="flex items-center justify-between p-2 bg-neutral-950 rounded-lg border border-neutral-800">
                            <div className="min-w-0">
                              <p className="text-xs text-neutral-200 truncate">{s.signal}</p>
                              <p className="text-xs text-neutral-500 truncate">{s.detail}</p>
                            </div>
                            <span className="text-xs font-semibold text-accent-400 shrink-0">+{s.points}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              ) : (
                <EmptyState title="No strategy yet" description="Generate content to see the AI outreach strategy." icon={<TrendingUp className="w-8 h-8" />} />
              )}
            </Section>
          </div>

          {/* Sent Emails section */}
          {sentEmails.length > 0 && (
            <Section title="Sent Outreach" icon={<Inbox className="w-4 h-4" />} action={<Badge variant="accent">{sentEmails.length}</Badge>}>
              <div className="space-y-3">
                {sentEmails.map((c) => (
                  <div key={c.id} className="p-4 bg-neutral-950 border border-neutral-800 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <div className="flex items-center gap-2">
                        <StatusBadge status={c.campaign_status} />
                        <span className="text-xs text-neutral-500">{new Date(c.created_at).toLocaleString()}</span>
                      </div>
                      <button
                        onClick={() => handleCopy(c.id, getCopyContent(c, activeChannel))}
                        className="btn-ghost text-xs"
                      >
                        {copied === c.id ? <Check className="w-3.5 h-3.5 text-accent-400" /> : <Copy className="w-3.5 h-3.5" />}
                      </button>
                    </div>
                    <p className="text-sm font-medium text-neutral-100">{c.email_subject}</p>
                    <div className="mt-2">
                      <pre className="text-xs text-neutral-400 whitespace-pre-wrap font-sans leading-relaxed">
                        {sentExpanded === c.id ? getDisplayContent(c, activeChannel) : getDisplayContent(c, activeChannel).slice(0, 150) + (getDisplayContent(c, activeChannel).length > 150 ? '...' : '')}
                      </pre>
                      {getDisplayContent(c, activeChannel).length > 150 && (
                        <button onClick={() => setSentExpanded(sentExpanded === c.id ? null : c.id)} className="btn-ghost text-xs mt-1 flex items-center gap-1">
                          {sentExpanded === c.id ? <ChevronUp className="w-3 h-3" /> : <ChevronDown className="w-3 h-3" />}
                          {sentExpanded === c.id ? 'Show less' : 'Show more'}
                        </button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </Section>
          )}
        </div>
      </div>
    </div>
  );
}

function getDisplayContent(campaign: OutreachCampaign, channel: OutreachChannel): string {
  switch (channel) {
    case 'linkedin': return campaign.linkedin_message || '';
    case 'call_script': return campaign.call_script || '';
    case 'objection_handling': {
      const responses = campaign.objection_responses || [];
      return responses.map((r) => `${r.objection}\n→ ${r.response}`).join('\n\n');
    }
    default: return campaign.email_content || '';
  }
}

function getCopyContent(campaign: OutreachCampaign, channel: OutreachChannel): string {
  const content = getDisplayContent(campaign, channel);
  return `Subject: ${campaign.email_subject}\n\n${content}`;
}

// ---- Channel-specific content renderer ----
function ChannelContent({
  campaign, channel, editSubject, editBody, onEditSubject, onEditBody,
  copied, onCopy, dirty, saving, sending, onSave, onSend, onStatusChange, toast,
}: {
  campaign: OutreachCampaign;
  channel: OutreachChannel;
  editSubject: string;
  editBody: string;
  onEditSubject: (v: string) => void;
  onEditBody: (v: string) => void;
  copied: string | null;
  onCopy: (id: string, content: string) => void;
  dirty: boolean;
  saving: boolean;
  sending: boolean;
  onSave: () => void;
  onSend: () => void;
  onStatusChange: (id: string, status: OutreachCampaign['campaign_status']) => void;
  toast: string | null;
}) {
  const isDraft = campaign.campaign_status === 'Draft';

  if (channel === 'objection_handling') {
    const responses: ObjectionResponse[] = campaign.objection_responses || [];
    return (
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <StatusBadge status={campaign.campaign_status} />
            <span className="text-xs text-neutral-500">{new Date(campaign.created_at).toLocaleDateString()}</span>
          </div>
          <button onClick={() => onCopy(campaign.id, responses.map((r) => `${r.objection}\n→ ${r.response}`).join('\n\n'))} className="btn-ghost text-xs">
            {copied === campaign.id ? <Check className="w-3.5 h-3.5 text-accent-400" /> : <Copy className="w-3.5 h-3.5" />}
            {copied === campaign.id ? 'Copied' : 'Copy'}
          </button>
        </div>
        <div className="space-y-3">
          {responses.map((r, i) => (
            <ObjectionCard key={i} objection={r.objection} response={r.response} />
          ))}
        </div>
        {toast && (
          <span className="flex items-center gap-1 text-xs text-accent-400 animate-fade-in">
            <Check className="w-3.5 h-3.5" /> {toast}
          </span>
        )}
      </div>
    );
  }

  if (channel === 'call_script') {
    const script = campaign.call_script || '';
    return (
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <StatusBadge status={campaign.campaign_status} />
            <span className="text-xs text-neutral-500">{new Date(campaign.created_at).toLocaleDateString()}</span>
          </div>
          <button onClick={() => onCopy(campaign.id, script)} className="btn-ghost text-xs">
            {copied === campaign.id ? <Check className="w-3.5 h-3.5 text-accent-400" /> : <Copy className="w-3.5 h-3.5" />}
            {copied === campaign.id ? 'Copied' : 'Copy'}
          </button>
        </div>
        <div className="bg-neutral-900 rounded-lg p-3">
          <pre className="text-xs text-neutral-300 whitespace-pre-wrap font-sans leading-relaxed">{script}</pre>
        </div>
        {isDraft && (
          <div className="flex items-center gap-2">
            <button onClick={onSend} disabled={sending} className="btn-primary text-xs flex items-center gap-1.5">
              {sending ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
              {sending ? 'Sending...' : 'Mark as Used'}
            </button>
          </div>
        )}
        {!isDraft && (
          <select
            value={campaign.campaign_status}
            onChange={(e) => onStatusChange(campaign.id, e.target.value as OutreachCampaign['campaign_status'])}
            className="text-xs bg-neutral-900 border border-neutral-700 rounded-lg px-2 py-1.5 text-neutral-200 focus:outline-none focus:border-primary-500"
          >
            {['Draft', 'Sent', 'Opened', 'Replied', 'Bounced'].map((s) => <option key={s} value={s}>{s}</option>)}
          </select>
        )}
        {toast && (
          <span className="flex items-center gap-1 text-xs text-accent-400 animate-fade-in">
            <Check className="w-3.5 h-3.5" /> {toast}
          </span>
        )}
      </div>
    );
  }

  if (channel === 'linkedin') {
    const message = campaign.linkedin_message || '';
    return (
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <StatusBadge status={campaign.campaign_status} />
            <span className="text-xs text-neutral-500">{new Date(campaign.created_at).toLocaleDateString()}</span>
          </div>
          <button onClick={() => onCopy(campaign.id, `Subject: ${campaign.email_subject}\n\n${message}`)} className="btn-ghost text-xs">
            {copied === campaign.id ? <Check className="w-3.5 h-3.5 text-accent-400" /> : <Copy className="w-3.5 h-3.5" />}
            {copied === campaign.id ? 'Copied' : 'Copy'}
          </button>
        </div>
        <div className="bg-neutral-900 rounded-lg p-3">
          <p className="text-xs text-neutral-500 mb-1">InMail Subject</p>
          <input
            type="text"
            value={editSubject}
            onChange={(e) => onEditSubject(e.target.value)}
            disabled={!isDraft}
            className="w-full bg-transparent text-sm font-medium text-neutral-100 focus:outline-none disabled:text-neutral-400"
          />
        </div>
        <div className="bg-neutral-900 rounded-lg p-3">
          <p className="text-xs text-neutral-500 mb-1">InMail Message</p>
          <textarea
            value={editBody || message}
            onChange={(e) => onEditBody(e.target.value)}
            disabled={!isDraft}
            rows={8}
            className="w-full bg-transparent text-sm text-neutral-300 focus:outline-none resize-y disabled:text-neutral-400 leading-relaxed"
          />
        </div>
        {isDraft && (
          <div className="flex items-center gap-2">
            <button onClick={onSave} disabled={saving || !dirty} className="btn-secondary text-xs flex items-center gap-1.5">
              {saving ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
              {saving ? 'Saving...' : 'Save'}
            </button>
            <button onClick={onSend} disabled={sending} className="btn-primary text-xs flex items-center gap-1.5">
              {sending ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
              {sending ? 'Sending...' : 'Send InMail'}
            </button>
            {dirty && <span className="text-xs text-warning-400">Unsaved changes</span>}
          </div>
        )}
        {!isDraft && (
          <select
            value={campaign.campaign_status}
            onChange={(e) => onStatusChange(campaign.id, e.target.value as OutreachCampaign['campaign_status'])}
            className="text-xs bg-neutral-900 border border-neutral-700 rounded-lg px-2 py-1.5 text-neutral-200 focus:outline-none focus:border-primary-500"
          >
            {['Draft', 'Sent', 'Opened', 'Replied', 'Bounced'].map((s) => <option key={s} value={s}>{s}</option>)}
          </select>
        )}
        {toast && (
          <span className="flex items-center gap-1 text-xs text-accent-400 animate-fade-in">
            <Check className="w-3.5 h-3.5" /> {toast}
          </span>
        )}
      </div>
    );
  }

  // Default: email channel (existing behavior)
  return (
    <div className="space-y-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <StatusBadge status={campaign.campaign_status} />
          <span className="text-xs text-neutral-500">{new Date(campaign.created_at).toLocaleDateString()}</span>
        </div>
        <button onClick={() => onCopy(campaign.id, `Subject: ${editSubject}\n\n${editBody}`)} className="btn-ghost text-xs">
          {copied === campaign.id ? <Check className="w-3.5 h-3.5 text-accent-400" /> : <Copy className="w-3.5 h-3.5" />}
          {copied === campaign.id ? 'Copied' : 'Copy'}
        </button>
      </div>
      <div className="bg-neutral-900 rounded-lg p-3">
        <p className="text-xs text-neutral-500 mb-1">Subject</p>
        <input
          type="text"
          value={editSubject}
          onChange={(e) => onEditSubject(e.target.value)}
          disabled={!isDraft}
          className="w-full bg-transparent text-sm font-medium text-neutral-100 focus:outline-none disabled:text-neutral-400"
        />
      </div>
      <div className="bg-neutral-900 rounded-lg p-3">
        <p className="text-xs text-neutral-500 mb-1">Body</p>
        <textarea
          value={editBody}
          onChange={(e) => onEditBody(e.target.value)}
          disabled={!isDraft}
          rows={8}
          className="w-full bg-transparent text-sm text-neutral-300 focus:outline-none resize-y disabled:text-neutral-400 leading-relaxed"
        />
      </div>
      {isDraft && (
        <div className="flex items-center gap-2">
          <button onClick={onSave} disabled={saving || !dirty} className="btn-secondary text-xs flex items-center gap-1.5">
            {saving ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Save className="w-3.5 h-3.5" />}
            {saving ? 'Saving...' : 'Save'}
          </button>
          <button onClick={onSend} disabled={sending} className="btn-primary text-xs flex items-center gap-1.5">
            {sending ? <RefreshCw className="w-3.5 h-3.5 animate-spin" /> : <Send className="w-3.5 h-3.5" />}
            {sending ? 'Sending...' : 'Send Email'}
          </button>
          {dirty && <span className="text-xs text-warning-400">Unsaved changes</span>}
        </div>
      )}
      {!isDraft && (
        <div className="flex items-center gap-2">
          <select
            value={campaign.campaign_status}
            onChange={(e) => onStatusChange(campaign.id, e.target.value as OutreachCampaign['campaign_status'])}
            className="text-xs bg-neutral-900 border border-neutral-700 rounded-lg px-2 py-1.5 text-neutral-200 focus:outline-none focus:border-primary-500"
          >
            {['Draft', 'Sent', 'Opened', 'Replied', 'Bounced'].map((s) => <option key={s} value={s}>{s}</option>)}
          </select>
        </div>
      )}
      {toast && (
        <span className="flex items-center gap-1 text-xs text-accent-400 animate-fade-in">
          <Check className="w-3.5 h-3.5" /> {toast}
        </span>
      )}
    </div>
  );
}

function ObjectionCard({ objection, response }: { objection: string; response: string }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="bg-neutral-950 border border-neutral-800 rounded-lg overflow-hidden">
      <button
        onClick={() => setOpen(!open)}
        className="w-full text-left p-3 flex items-start gap-3 hover:bg-neutral-900/50 transition-colors"
      >
        <AlertCircle className="w-4 h-4 text-warning-400 shrink-0 mt-0.5" />
        <div className="min-w-0 flex-1">
          <p className="text-sm text-neutral-200">{objection}</p>
        </div>
        <ChevronDown className={`w-4 h-4 text-neutral-500 shrink-0 mt-0.5 transition-transform ${open ? 'rotate-180' : ''}`} />
      </button>
      {open && (
        <div className="px-3 pb-3 pl-10 animate-fade-in">
          <div className="flex items-start gap-2">
            <Check className="w-4 h-4 text-accent-400 shrink-0 mt-0.5" />
            <p className="text-sm text-neutral-300 leading-relaxed">{response}</p>
          </div>
        </div>
      )}
    </div>
  );
}

function StrategyRow({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="flex items-start gap-3 p-3 bg-neutral-950 rounded-lg border border-neutral-800">
      <span className="text-primary-400 mt-0.5">{icon}</span>
      <div className="min-w-0">
        <p className="text-xs text-neutral-500">{label}</p>
        <p className="text-sm text-neutral-200 mt-0.5">{value}</p>
      </div>
    </div>
  );
}
