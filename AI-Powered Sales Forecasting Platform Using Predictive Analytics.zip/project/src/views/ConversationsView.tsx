import { useEffect, useState } from 'react';
import {
  Phone, MessageSquare, Calendar, Plus, Clock, CheckCircle2, X,
  Zap, Database, RefreshCw, Sparkles, Mail, Activity, User,
  FileText, ChevronDown, ChevronUp, AlertCircle,
} from 'lucide-react';
import type { Lead, SalesInteraction, CrmSyncLog } from '../types';
import { fetchLeads, fetchInteractions, logInteraction, fetchSyncLogs, syncToCrm } from '../lib/api';
import { generateCrmSyncActivity } from '../lib/aiEngine';
import { Section, LoadingSpinner, EmptyState, ErrorState, Badge } from '../components/ui';

const TYPE_ICON: Record<string, React.ReactNode> = {
  Call: <Phone className="w-4 h-4" />,
  Meeting: <Calendar className="w-4 h-4" />,
  Email: <Mail className="w-4 h-4" />,
  Demo: <Zap className="w-4 h-4" />,
  'Follow-up': <CheckCircle2 className="w-4 h-4" />,
};

const ACTIVITY_ICON: Record<string, React.ReactNode> = {
  Call: <Phone className="w-3.5 h-3.5" />,
  Meeting: <Calendar className="w-3.5 h-3.5" />,
  Email: <Mail className="w-3.5 h-3.5" />,
  Demo: <Zap className="w-3.5 h-3.5" />,
  'Follow-up': <CheckCircle2 className="w-3.5 h-3.5" />,
};

const ACTIVITY_COLOR: Record<string, string> = {
  Call: 'bg-primary-500/20 text-primary-400',
  Meeting: 'bg-accent-500/20 text-accent-400',
  Email: 'bg-warning-500/20 text-warning-400',
  Demo: 'bg-error-500/20 text-error-400',
  'Follow-up': 'bg-neutral-500/20 text-neutral-400',
};

const SYNC_BADGE: Record<string, { label: string; color: string }> = {
  'Contact Added':    { label: 'Added',   color: 'bg-accent-500/20 text-accent-300 border-accent-500/30' },
  'Status Update':    { label: 'Updated', color: 'bg-primary-500/20 text-primary-300 border-primary-500/30' },
  'Activity Logged':  { label: 'Logged',  color: 'bg-warning-500/20 text-warning-300 border-warning-500/30' },
  'Stage Move':       { label: 'Moved',   color: 'bg-accent-500/20 text-accent-300 border-accent-500/30' },
  'Task Created':     { label: 'New',     color: 'bg-primary-500/20 text-primary-300 border-primary-500/30' },
};

function relativeTime(ts: string) {
  const diff = Date.now() - new Date(ts).getTime();
  const m = Math.floor(diff / 60000);
  if (m < 1) return 'just now';
  if (m < 60) return `${m} min ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h} hour${h === 1 ? '' : 's'} ago`;
  return `${Math.floor(h / 24)} day${Math.floor(h / 24) === 1 ? '' : 's'} ago`;
}

export function ConversationsView() {
  const [leads, setLeads] = useState<Lead[]>([]);
  const [selectedLeadId, setSelectedLeadId] = useState<string | null>(null);
  const [interactions, setInteractions] = useState<SalesInteraction[]>([]);
  const [syncLogs, setSyncLogs] = useState<CrmSyncLog[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [showLog, setShowLog] = useState(false);
  const [transcript, setTranscript] = useState('');
  const [interactionType, setInteractionType] = useState<SalesInteraction['interaction_type']>('Call');
  const [duration, setDuration] = useState(30);
  const [logging, setLogging] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const [activeInteraction, setActiveInteraction] = useState<SalesInteraction | null>(null);
  const [expandedPoints, setExpandedPoints] = useState(false);

  useEffect(() => { loadLeads(); }, []);
  useEffect(() => { if (selectedLeadId) loadAll(selectedLeadId); }, [selectedLeadId]);

  async function loadLeads() {
    try {
      setLoading(true);
      const data = await fetchLeads();
      setLeads(data);
      if (data.length > 0) setSelectedLeadId(data[0].id);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load leads');
    } finally {
      setLoading(false);
    }
  }

  async function loadAll(leadId: string) {
    try {
      const [i, s] = await Promise.all([fetchInteractions(leadId), fetchSyncLogs(leadId)]);
      setInteractions(i);
      setSyncLogs(s);
      setActiveInteraction(i.length > 0 ? i[0] : null);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load data');
    }
  }

  async function handleLogInteraction() {
    if (!selectedLeadId || !transcript.trim()) return;
    try {
      setLogging(true);
      const lead = leads.find((item) => item.id === selectedLeadId);
      if (!lead) throw new Error('Select a lead before logging an interaction');
      const result = await logInteraction(lead, transcript, interactionType, Math.max(0, duration));
      setTranscript('');
      setDuration(30);
      setShowLog(false);
      await loadAll(selectedLeadId);
      setActiveInteraction(result);
      setExpandedPoints(false);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to log interaction');
    } finally {
      setLogging(false);
    }
  }

  async function handleSyncCrm() {
    if (!selectedLeadId) return;
    const lead = leads.find((l) => l.id === selectedLeadId);
    if (!lead) return;
    try {
      setSyncing(true);
      const activity = generateCrmSyncActivity(lead, null);
      await syncToCrm(selectedLeadId, 'Salesforce', activity.sync_type, activity.summary);
      if (interactions.length > 0) {
        await syncToCrm(selectedLeadId, 'Salesforce', 'Activity Logged', `Initial outreach email sent and activity recorded for ${lead.contact_name}`);
      }
      await loadAll(selectedLeadId);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'CRM sync failed');
    } finally {
      setSyncing(false);
    }
  }

  const selectedLead = leads.find((l) => l.id === selectedLeadId);
  const latestSync = syncLogs[0];
  const syncState = latestSync?.sync_status ?? null;

  if (loading) return <LoadingSpinner label="Loading conversations..." />;

  if (leads.length === 0) {
    return (
      <div className="card">
        <EmptyState title="No leads available" description="Add a lead before logging conversations or syncing CRM activity." icon={<User className="w-8 h-8" />} />
      </div>
    );
  }

  return (
    <div className="space-y-4 animate-fade-in">
      {error && <ErrorState message={error} />}

      {/* Lead selector + action bar */}
      <div className="card p-4 flex flex-col sm:flex-row sm:items-center gap-3">
        <div className="flex items-center gap-2 flex-1 min-w-0">
          <User className="w-4 h-4 text-neutral-500 shrink-0" />
          <select
            className="input flex-1 min-w-0"
            value={selectedLeadId ?? ''}
            onChange={(e) => setSelectedLeadId(e.target.value)}
          >
            {leads.map((l) => (
              <option key={l.id} value={l.id}>{l.company_name} — {l.contact_name}</option>
            ))}
          </select>
        </div>
        <div className="flex gap-2 shrink-0">
          <button onClick={handleSyncCrm} disabled={syncing || !selectedLeadId} className="btn-secondary text-sm flex items-center gap-1.5">
            {syncing ? <RefreshCw className="w-4 h-4 animate-spin" /> : <Database className="w-4 h-4" />}
            {syncing ? 'Syncing...' : 'Sync to CRM'}
          </button>
          <button onClick={() => setShowLog(!showLog)} className="btn-primary text-sm flex items-center gap-1.5">
            <Plus className="w-4 h-4" />
            Log Interaction
          </button>
        </div>
      </div>

      {/* Log interaction form */}
      {showLog && (
        <div className="card p-4 space-y-3 animate-slide-up border border-primary-500/20">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-primary-400" />
              <h4 className="text-sm font-semibold text-neutral-100">Log Interaction + AI Summarize</h4>
            </div>
            <button onClick={() => setShowLog(false)} className="btn-ghost p-1"><X className="w-4 h-4" /></button>
          </div>
          <div className="flex gap-2">
            <select className="input flex-1" value={interactionType} onChange={(e) => setInteractionType(e.target.value as SalesInteraction['interaction_type'])}>
              {['Call', 'Meeting', 'Email', 'Demo', 'Follow-up'].map((t) => <option key={t}>{t}</option>)}
            </select>
            <div className="flex items-center gap-2">
              <Clock className="w-4 h-4 text-neutral-500" />
              <input type="number" className="input w-20" value={duration} onChange={(e) => setDuration(Number(e.target.value))} />
              <span className="text-xs text-neutral-500">min</span>
            </div>
          </div>
          <textarea
            className="input min-h-[100px] resize-y"
            placeholder="Paste call transcript or meeting notes here — AI will extract key points and action items automatically..."
            value={transcript}
            onChange={(e) => setTranscript(e.target.value)}
          />
          <button onClick={handleLogInteraction} disabled={logging || !transcript.trim()} className="btn-primary w-full">
            {logging ? (
              <><RefreshCw className="w-4 h-4 animate-spin" /> Analyzing with AI...</>
            ) : (
              <><Sparkles className="w-4 h-4" /> Log & AI Summarize</>
            )}
          </button>
        </div>
      )}

      {/* 3-panel layout */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4">

        {/* LEFT: CRM Sync Status */}
        <div className="lg:col-span-3">
          <Section title="CRM Sync Status" icon={<Database className="w-4 h-4" />} action={
            <span className={`flex items-center gap-1.5 text-xs font-medium ${
              syncState === 'Failed' ? 'text-error-400' : syncState === 'Pending' ? 'text-warning-400' : 'text-accent-400'
            }`}>
              <span className={`w-2 h-2 rounded-full ${
                syncState === 'Failed' ? 'bg-error-400' : syncState === 'Pending' ? 'bg-warning-400' : 'bg-accent-400'
              } ${syncState === 'Pending' ? 'animate-pulse' : ''}`} />
              {syncState ?? 'Not synced'}
            </span>
          }>
            {syncLogs.length === 0 ? (
              <EmptyState
                title="No sync activity"
                description="Click Sync to CRM to push this lead's data."
                icon={<Database className="w-6 h-6" />}
              />
            ) : (
              <div className="space-y-3">
                {syncLogs.slice(0, 8).map((log) => {
                  const badge = SYNC_BADGE[log.sync_type] ?? { label: log.sync_type, color: 'bg-neutral-500/20 text-neutral-300 border-neutral-500/30' };
                  return (
                    <div key={log.id} className="p-3 bg-neutral-950 border border-neutral-800 rounded-lg">
                      <div className="flex items-start justify-between gap-2 mb-1">
                        <p className="text-xs font-semibold text-neutral-200 leading-snug">{log.sync_type}</p>
                        <span className={`text-[10px] font-bold px-1.5 py-0.5 rounded border ${badge.color} shrink-0`}>{badge.label}</span>
                      </div>
                      <p className="text-xs text-neutral-400 line-clamp-2 leading-snug">{log.details.split('\n')[0]}</p>
                      <p className="text-[10px] text-neutral-600 mt-1">{relativeTime(log.timestamp)}</p>
                    </div>
                  );
                })}
              </div>
            )}
          </Section>
        </div>

        {/* CENTER: Meeting Summary */}
        <div className="lg:col-span-5">
          <Section
            title="Meeting Summary"
            icon={<FileText className="w-4 h-4" />}
            action={
              <span className="flex items-center gap-1 px-2 py-0.5 rounded-full bg-primary-500/10 border border-primary-500/20 text-xs text-primary-400 font-medium">
                <Sparkles className="w-3 h-3" /> AI Powered
              </span>
            }
          >
            {interactions.length === 0 ? (
              <EmptyState
                title="No conversations yet"
                description="Log a call or meeting to see the AI-generated summary with key points and action items."
                icon={<MessageSquare className="w-8 h-8" />}
              />
            ) : (
              <div className="space-y-4">
                {/* Interaction selector tabs */}
                {interactions.length > 1 && (
                  <div className="flex gap-2 flex-wrap">
                    {interactions.slice(0, 4).map((i) => (
                      <button
                        key={i.id}
                        onClick={() => setActiveInteraction(i)}
                        className={`flex items-center gap-1.5 px-2.5 py-1 rounded-lg text-xs border transition-colors ${
                          activeInteraction?.id === i.id
                            ? 'bg-primary-500/10 border-primary-500/40 text-primary-300'
                            : 'bg-neutral-950 border-neutral-800 text-neutral-400 hover:border-neutral-700'
                        }`}
                      >
                        <span className="text-primary-400">{TYPE_ICON[i.interaction_type]}</span>
                        {i.interaction_type}
                      </button>
                    ))}
                  </div>
                )}

                {activeInteraction && (
                  <div className="space-y-4">
                    {/* Header */}
                    <div className="flex items-center gap-3 p-3 bg-neutral-950 rounded-lg border border-neutral-800">
                      <span className={`w-8 h-8 rounded-lg flex items-center justify-center ${ACTIVITY_COLOR[activeInteraction.interaction_type]}`}>
                        {TYPE_ICON[activeInteraction.interaction_type]}
                      </span>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <p className="text-sm font-medium text-neutral-100">{selectedLead?.contact_name}</p>
                          {selectedLead?.contact_title && (
                            <span className="text-xs text-neutral-500">{selectedLead.contact_title}</span>
                          )}
                        </div>
                        <div className="flex items-center gap-3 mt-0.5">
                          <span className="flex items-center gap-1 text-xs text-neutral-400">
                            <Clock className="w-3 h-3" /> {activeInteraction.duration_minutes} min
                          </span>
                          <span className="text-xs text-neutral-400">
                            {new Date(activeInteraction.interaction_date).toLocaleDateString()}
                          </span>
                          {selectedLead && (
                            <span className="text-xs text-neutral-500">{selectedLead.company_name}</span>
                          )}
                        </div>
                      </div>
                      <Badge variant="primary">{activeInteraction.interaction_type}</Badge>
                    </div>

                    {/* AI Summary */}
                    {activeInteraction.summary && (
                      <div className="relative p-4 rounded-xl bg-gradient-to-br from-primary-500/10 via-primary-500/5 to-transparent border border-primary-500/20">
                        <div className="flex items-center gap-2 mb-3">
                          <span className="w-7 h-7 rounded-lg bg-primary-500/20 flex items-center justify-center">
                            <Sparkles className="w-4 h-4 text-primary-400" />
                          </span>
                          <p className="text-sm font-semibold text-primary-300">AI-Generated Summary</p>
                          <span className="ml-auto text-[10px] font-medium px-2 py-0.5 rounded-full bg-primary-500/15 border border-primary-500/25 text-primary-400">
                            Auto-generated
                          </span>
                        </div>
                        <p className="text-sm text-neutral-200 leading-relaxed">{activeInteraction.summary}</p>
                      </div>
                    )}

                    {/* Key Discussion Points */}
                    {activeInteraction.key_points.length > 0 && (
                      <div>
                        <button
                          onClick={() => setExpandedPoints(!expandedPoints)}
                          className="flex items-center gap-2 w-full mb-2"
                        >
                          <p className="text-xs font-semibold text-neutral-400 uppercase tracking-wide">Key Discussion Points</p>
                          {expandedPoints ? <ChevronUp className="w-3.5 h-3.5 text-neutral-500" /> : <ChevronDown className="w-3.5 h-3.5 text-neutral-500" />}
                        </button>
                        <ul className="space-y-2">
                          {(expandedPoints ? activeInteraction.key_points : activeInteraction.key_points.slice(0, 4)).map((p, i) => (
                            <li key={i} className="flex items-start gap-2 text-sm text-neutral-300">
                              <span className="w-1.5 h-1.5 rounded-full bg-primary-400 mt-2 shrink-0" />
                              {p.point}
                            </li>
                          ))}
                        </ul>
                        {!expandedPoints && activeInteraction.key_points.length > 4 && (
                          <button onClick={() => setExpandedPoints(true)} className="text-xs text-primary-400 mt-2 hover:text-primary-300">
                            +{activeInteraction.key_points.length - 4} more points
                          </button>
                        )}
                      </div>
                    )}

                    {/* Action Items */}
                    {activeInteraction.action_items.length > 0 && (
                      <div>
                        <p className="text-xs font-semibold text-neutral-400 uppercase tracking-wide mb-2">Action Items</p>
                        <div className="space-y-2">
                          {activeInteraction.action_items.map((a, i) => (
                            <div key={i} className="flex items-start gap-3 p-3 bg-neutral-950 border border-neutral-800 rounded-lg">
                              <AlertCircle className="w-4 h-4 text-warning-400 mt-0.5 shrink-0" />
                              <div className="flex-1 min-w-0">
                                <p className="text-sm text-neutral-200">{a.action}</p>
                                <div className="flex items-center gap-3 mt-1">
                                  <span className="text-xs text-neutral-500">Owner: {a.owner}</span>
                                  {a.due && <span className="text-xs text-error-400">Due: {a.due}</span>}
                                </div>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}
          </Section>
        </div>

        {/* RIGHT: Recent Activity */}
        <div className="lg:col-span-4">
          <Section title="Recent Activity" icon={<Activity className="w-4 h-4" />}>
            {interactions.length === 0 ? (
              <EmptyState
                title="No activity yet"
                description="Logged interactions will appear here as a timeline."
                icon={<Activity className="w-6 h-6" />}
              />
            ) : (
              <div className="space-y-3">
                {interactions.slice(0, 8).map((i, idx) => {
                  const colorClass = ACTIVITY_COLOR[i.interaction_type] ?? 'bg-neutral-500/20 text-neutral-400';
                  return (
                    <div key={i.id} className="flex gap-3">
                      <div className="flex flex-col items-center">
                        <span className={`w-7 h-7 rounded-lg flex items-center justify-center shrink-0 ${colorClass}`}>
                          {ACTIVITY_ICON[i.interaction_type]}
                        </span>
                        {idx < interactions.slice(0, 8).length - 1 && (
                          <div className="w-px flex-1 bg-neutral-800 mt-1 min-h-[16px]" />
                        )}
                      </div>
                      <div className="pb-3 min-w-0 flex-1">
                        <button
                          onClick={() => setActiveInteraction(i)}
                          className="text-left w-full group"
                        >
                          <p className="text-sm text-neutral-200 group-hover:text-white transition-colors">
                            {i.interaction_type} — {selectedLead?.company_name}
                          </p>
                          {i.summary && (
                            <p className="text-xs text-neutral-500 mt-0.5 line-clamp-2 leading-snug">{i.summary}</p>
                          )}
                          <p className="text-[10px] text-neutral-600 mt-1">{relativeTime(i.interaction_date)}</p>
                        </button>
                      </div>
                    </div>
                  );
                })}

                {syncLogs.slice(0, 3).map((log, idx) => (
                  <div key={log.id} className="flex gap-3">
                    <div className="flex flex-col items-center">
                      <span className="w-7 h-7 rounded-lg flex items-center justify-center shrink-0 bg-accent-500/20 text-accent-400">
                        <Database className="w-3.5 h-3.5" />
                      </span>
                      {idx < syncLogs.slice(0, 3).length - 1 && (
                        <div className="w-px flex-1 bg-neutral-800 mt-1 min-h-[16px]" />
                      )}
                    </div>
                    <div className="pb-3 min-w-0 flex-1">
                      <p className="text-sm text-neutral-200">{log.sync_type} — {log.crm_platform}</p>
                      <p className="text-xs text-neutral-500 mt-0.5 line-clamp-1">{log.details.split('\n')[0]}</p>
                      <p className="text-[10px] text-neutral-600 mt-1">{relativeTime(log.timestamp)}</p>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </Section>
        </div>
      </div>
    </div>
  );
}
