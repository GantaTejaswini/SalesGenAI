import { Sparkles, Zap, Target, BarChart3, Mail, MessageSquare, ArrowRight, CheckCircle2, TrendingUp, Brain, ShieldCheck } from 'lucide-react';

interface HomePageProps {
  onGetStarted: () => void;
  onSignIn: () => void;
}

export function HomePage({ onGetStarted, onSignIn }: HomePageProps) {
  return (
    <div className="min-h-screen bg-neutral-950 text-neutral-100">
      {/* Nav */}
      <nav className="sticky top-0 z-50 bg-neutral-950/80 backdrop-blur-lg border-b border-neutral-800">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-gradient-to-br from-primary-500 to-primary-700 flex items-center justify-center">
              <Sparkles className="w-5 h-5 text-white" />
            </div>
            <span className="text-base font-bold text-white">AI-Powered Sales Forecasting</span>
          </div>
          <div className="flex items-center gap-2">
            <button onClick={onSignIn} className="btn-ghost text-sm">Sign In</button>
            <button onClick={onGetStarted} className="btn-primary text-sm">Get Started</button>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="relative overflow-hidden">
        <div className="absolute inset-0 bg-gradient-to-b from-primary-500/5 via-transparent to-transparent" />
        <div className="absolute top-20 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-primary-500/10 rounded-full blur-[120px]" />
        <div className="relative max-w-6xl mx-auto px-4 sm:px-6 pt-20 pb-24 text-center">
          <div className="inline-flex items-center gap-2 px-3 py-1.5 bg-accent-500/10 border border-accent-500/20 rounded-full mb-6 animate-fade-in">
            <Zap className="w-3.5 h-3.5 text-accent-400" />
            <span className="text-xs font-medium text-accent-300">AI-Powered Sales Intelligence Platform</span>
          </div>
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white leading-tight max-w-3xl mx-auto animate-slide-up">
            Turn prospects into pipeline with{' '}
            <span className="bg-gradient-to-r from-primary-400 to-accent-400 bg-clip-text text-transparent">AI intelligence</span>
          </h1>
          <p className="text-lg text-neutral-400 mt-6 max-w-2xl mx-auto leading-relaxed animate-slide-up">
            Our AI-powered sales forecasting platform analyzes companies, scores leads with explainable predictive signals, writes personalized outreach, and summarizes your calls — all driven by predictive analytics.
          </p>
          <div className="flex items-center justify-center gap-3 mt-8 animate-slide-up">
            <button onClick={onGetStarted} className="btn-primary text-base px-6 py-3">
              Start Free <ArrowRight className="w-4 h-4" />
            </button>
            <button onClick={onSignIn} className="btn-secondary text-base px-6 py-3">
              Sign In
            </button>
          </div>
          <p className="text-xs text-neutral-600 mt-4">No credit card required · Demo-ready in seconds</p>
        </div>
      </section>

      {/* Stats bar */}
      <section className="border-y border-neutral-800 bg-neutral-900/50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-10 grid grid-cols-2 md:grid-cols-4 gap-6">
          <Stat value="119+" label="Demo leads loaded" />
          <Stat value="0–100" label="Explainable signal scores" />
          <Stat value="4" label="AI-powered modules" />
          <Stat value="8" label="Relational data tables" />
        </div>
      </section>

      {/* Features */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 py-20">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold text-white">Everything your sales team needs</h2>
          <p className="text-neutral-400 mt-3">Four AI-powered modules that work together across the entire sales workflow.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Feature
            icon={<Target className="w-6 h-6" />}
            color="primary"
            title="Lead Intelligence"
            description="Analyze companies, score leads 0–100 with explainable factors, and see AI-generated business needs, opportunities, and industry insights."
          />
          <Feature
            icon={<Mail className="w-6 h-6" />}
            color="accent"
            title="Outreach Generation"
            description="Generate personalized email drafts that reference the specific signals — funding stage, tech stack — that made the lead attractive."
          />
          <Feature
            icon={<MessageSquare className="w-6 h-6" />}
            color="warning"
            title="Conversation Intelligence"
            description="Paste a call transcript and get a structured AI summary, key points, and action items with owners and due dates. Sync to your CRM."
          />
          <Feature
            icon={<BarChart3 className="w-6 h-6" />}
            color="error"
            title="Sales Dashboard"
            description="Track pipeline value, conversion rates, average signal scores, and your top leads — all in one real-time analytics view."
          />
        </div>
      </section>

      {/* How it works */}
      <section className="bg-neutral-900/50 border-y border-neutral-800">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-20">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-white">How it works</h2>
            <p className="text-neutral-400 mt-3">The agentic intelligence pipeline runs end-to-end in one click.</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Step num="1" icon={<Brain className="w-5 h-5" />} title="Analyze" description="AI examines firmographics, tech stack, and funding signals to build a company profile." />
            <Step num="2" icon={<TrendingUp className="w-5 h-5" />} title="Score" description="An explainable 0–100 score with named contributing factors and conversion probability." />
            <Step num="3" icon={<Zap className="w-5 h-5" />} title="Act" description="Personalized outreach, follow-up recommendations, and CRM-ready summaries — automatically." />
          </div>
        </div>
      </section>

      {/* Trust */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 py-20">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Trust icon={<ShieldCheck className="w-5 h-5" />} title="Provider-agnostic AI" description="Pluggable engine works with or without an LLM API key — always demoable, zero vendor lock-in." />
          <Trust icon={<CheckCircle2 className="w-5 h-5" />} title="Audit-trail scoring" description="Scores are stored as timestamped rows so you can see how a lead's signal evolved over time." />
          <Trust icon={<TrendingUp className="w-5 h-5" />} title="Built on Supabase" description="Normalized 8-table schema with row-level security, ready to scale from demo to production." />
        </div>
      </section>

      {/* CTA */}
      <section className="max-w-6xl mx-auto px-4 sm:px-6 pb-20">
        <div className="card p-10 text-center bg-gradient-to-br from-primary-500/10 to-accent-500/5 border-primary-500/20">
          <h2 className="text-3xl font-bold text-white">Ready to close more deals?</h2>
          <p className="text-neutral-400 mt-3 max-w-xl mx-auto">Create your account and start running AI intelligence on your leads in minutes.</p>
          <button onClick={onGetStarted} className="btn-primary text-base px-6 py-3 mt-6">
            Get Started Free <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-neutral-800">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="w-7 h-7 rounded-md bg-gradient-to-br from-primary-500 to-primary-700 flex items-center justify-center">
              <Sparkles className="w-4 h-4 text-white" />
            </div>
            <span className="text-sm font-medium text-neutral-400">AI-Powered Sales Forecasting Platform</span>
          </div>
          <p className="text-xs text-neutral-600">Built with React, Supabase & an explainable AI engine.</p>
        </div>
      </footer>
    </div>
  );
}

function Stat({ value, label }: { value: string; label: string }) {
  return (
    <div className="text-center">
      <p className="text-2xl font-bold text-white">{value}</p>
      <p className="text-sm text-neutral-500 mt-1">{label}</p>
    </div>
  );
}

function Feature({ icon, color, title, description }: { icon: React.ReactNode; color: 'primary' | 'accent' | 'warning' | 'error'; title: string; description: string }) {
  const colors: Record<string, string> = {
    primary: 'text-primary-400 bg-primary-500/10',
    accent: 'text-accent-400 bg-accent-500/10',
    warning: 'text-warning-400 bg-warning-500/10',
    error: 'text-error-400 bg-error-500/10',
  };
  return (
    <div className="card card-hover p-6">
      <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-4 ${colors[color]}`}>{icon}</div>
      <h3 className="text-lg font-semibold text-white">{title}</h3>
      <p className="text-sm text-neutral-400 mt-2 leading-relaxed">{description}</p>
    </div>
  );
}

function Step({ num, icon, title, description }: { num: string; icon: React.ReactNode; title: string; description: string }) {
  return (
    <div className="text-center">
      <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-primary-500/10 border border-primary-500/20 text-primary-400 mb-4">
        {icon}
      </div>
      <div className="text-xs font-semibold text-primary-400 mb-1">STEP {num}</div>
      <h3 className="text-lg font-semibold text-white">{title}</h3>
      <p className="text-sm text-neutral-400 mt-2 leading-relaxed">{description}</p>
    </div>
  );
}

function Trust({ icon, title, description }: { icon: React.ReactNode; title: string; description: string }) {
  return (
    <div className="flex items-start gap-3">
      <div className="w-10 h-10 rounded-lg bg-neutral-800 flex items-center justify-center text-accent-400 shrink-0">{icon}</div>
      <div>
        <h3 className="text-sm font-semibold text-white">{title}</h3>
        <p className="text-sm text-neutral-400 mt-1 leading-relaxed">{description}</p>
      </div>
    </div>
  );
}
