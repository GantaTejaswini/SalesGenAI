import { useEffect, useState } from 'react';
import { TrendingUp, Users, DollarSign, Clock, Target, Award, Activity, PieChart, BarChart3, LineChart } from 'lucide-react';
import type { Lead, SalesAnalytics, RevenueForecast } from '../types';
import { fetchLeads, fetchAnalytics, fetchScores, fetchRevenueForecast } from '../lib/api';
import { Section, StatusBadge, LoadingSpinner, ErrorState, Badge } from '../components/ui';
import { SignalGauge } from '../components/SignalGauge';
import { RevenueChart } from '../components/RevenueChart';

export function DashboardView() {
  const [leads, setLeads] = useState<Lead[]>([]);
  const [analytics, setAnalytics] = useState<SalesAnalytics[]>([]);
  const [scoreMap, setScoreMap] = useState<Record<string, number>>({});
  const [forecast, setForecast] = useState<RevenueForecast[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadAll();
  }, []);

  async function loadAll() {
    try {
      setLoading(true);
      const [l, a] = await Promise.all([fetchLeads(), fetchAnalytics()]);
      setLeads(l);
      setAnalytics(a);

      const scores: Record<string, number> = {};
      await Promise.all(
        l.map(async (lead) => {
          const s = await fetchScores(lead.id);
          if (s.length > 0) scores[lead.id] = s[0].lead_score;
        })
      );
      setScoreMap(scores);

      const latestAnalytics = a[0] || null;
      const forecastData = await fetchRevenueForecast(
        l,
        scores,
        latestAnalytics ? { pipeline_value: latestAnalytics.pipeline_value, conversion_rate: latestAnalytics.conversion_rate, closed_won: latestAnalytics.closed_won } : null,
      );
      setForecast(forecastData);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load dashboard');
    } finally {
      setLoading(false);
    }
  }

  if (loading) return <LoadingSpinner label="Loading dashboard..." />;
  if (error) return <ErrorState message={error} />;

  const latestAnalytics = analytics[0];

  const statusCounts = leads.reduce<Record<string, number>>((acc, l) => {
    acc[l.lead_status] = (acc[l.lead_status] || 0) + 1;
    return acc;
  }, {});

  const priorityCounts = leads.reduce<Record<string, number>>((acc, l) => {
    acc[l.priority] = (acc[l.priority] || 0) + 1;
    return acc;
  }, {});

  const industryCounts = leads.reduce<Record<string, number>>((acc, l) => {
    acc[l.industry] = (acc[l.industry] || 0) + 1;
    return acc;
  }, {});

  const avgScore = Object.values(scoreMap).length > 0
    ? Math.round(Object.values(scoreMap).reduce((a, b) => a + b, 0) / Object.values(scoreMap).length)
    : 0;

  const topLeads = [...leads]
    .map((l) => ({ ...l, score: scoreMap[l.id] ?? 0 }))
    .sort((a, b) => b.score - a.score)
    .slice(0, 5);

  const statusColors: Record<string, string> = {
    New: '#32a0ff',
    Qualified: '#10b981',
    Proposal: '#f59e0b',
    Negotiation: '#fbbf24',
    'Closed Won': '#10b981',
    'Closed Lost': '#ef4444',
  };

  return (
    <div className="space-y-6 animate-fade-in">
      {/* KPI cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <KpiCard
          icon={<Users className="w-5 h-5" />}
          label="Total Leads"
          value={leads.length.toString()}
          sub={`${statusCounts['Qualified'] || 0} qualified`}
          color="primary"
        />
        <KpiCard
          icon={<DollarSign className="w-5 h-5" />}
          label="Pipeline Value"
          value={latestAnalytics ? `$${(latestAnalytics.pipeline_value / 1000000).toFixed(1)}M` : '—'}
          sub={latestAnalytics ? `${latestAnalytics.conversion_rate}% conversion` : ''}
          color="accent"
        />
        <KpiCard
          icon={<Clock className="w-5 h-5" />}
          label="Avg Response Time"
          value={latestAnalytics ? `${latestAnalytics.avg_response_time_hours}h` : '—'}
          sub={latestAnalytics ? `${latestAnalytics.avg_sales_cycle_days}d cycle` : ''}
          color="warning"
        />
        <KpiCard
          icon={<Award className="w-5 h-5" />}
          label="Closed Won"
          value={latestAnalytics ? latestAnalytics.closed_won.toString() : '—'}
          sub={latestAnalytics ? `${latestAnalytics.closed_lost} lost` : ''}
          color="error"
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Avg signal score gauge */}
        <Section title="Average Signal Score" icon={<Target className="w-4 h-4" />}>
          <div className="flex flex-col items-center justify-center py-4">
            <SignalGauge score={avgScore} conversionProbability={Math.round(avgScore * 0.85)} />
            <p className="text-sm text-neutral-400 mt-3">
              Across {Object.keys(scoreMap).length} scored leads
            </p>
          </div>
        </Section>

        {/* Pipeline by status */}
        <Section title="Pipeline by Status" icon={<BarChart3 className="w-4 h-4" />}>
          <div className="space-y-3 py-2">
            {Object.entries(statusCounts).map(([status, count]) => {
              const pct = leads.length > 0 ? (count / leads.length) * 100 : 0;
              return (
                <div key={status}>
                  <div className="flex items-center justify-between mb-1">
                    <span className="text-sm text-neutral-300">{status}</span>
                    <span className="text-sm text-neutral-500">{count}</span>
                  </div>
                  <div className="h-2 bg-neutral-800 rounded-full overflow-hidden">
                    <div
                      className="h-full rounded-full transition-all duration-700"
                      style={{ width: `${pct}%`, backgroundColor: statusColors[status] || '#64748b' }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </Section>

        {/* Priority distribution */}
        <Section title="Priority Distribution" icon={<Activity className="w-4 h-4" />}>
          <div className="space-y-3 py-2">
            {(['High', 'Medium', 'Low'] as const).map((p) => {
              const count = priorityCounts[p] || 0;
              const pct = leads.length > 0 ? (count / leads.length) * 100 : 0;
              const color = p === 'High' ? '#ef4444' : p === 'Medium' ? '#f59e0b' : '#64748b';
              return (
                <div key={p}>
                  <div className="flex items-center justify-between mb-1">
                    <div className="flex items-center gap-2">
                      <span className="w-2 h-2 rounded-full" style={{ backgroundColor: color }} />
                      <span className="text-sm text-neutral-300">{p} Priority</span>
                    </div>
                    <span className="text-sm text-neutral-500">{count}</span>
                  </div>
                  <div className="h-2 bg-neutral-800 rounded-full overflow-hidden">
                    <div className="h-full rounded-full transition-all duration-700" style={{ width: `${pct}%`, backgroundColor: color }} />
                  </div>
                </div>
              );
            })}
            <div className="pt-3 mt-3 border-t border-neutral-800">
              <p className="text-xs text-neutral-500 mb-2">Industry Breakdown</p>
              <div className="flex flex-wrap gap-1.5">
                {Object.entries(industryCounts).map(([ind, count]) => (
                  <Badge key={ind} variant="neutral">{ind} ({count})</Badge>
                ))}
              </div>
            </div>
          </div>
        </Section>
      </div>

      {/* Revenue Forecast Chart */}
      {forecast.length > 0 && (
        <Section title="Revenue Forecast — 6-Month Projection" icon={<LineChart className="w-4 h-4" />}>
          <RevenueChart data={forecast} />
        </Section>
      )}

      {/* Top leads */}
      <Section title="Top Leads by Signal Score" icon={<TrendingUp className="w-4 h-4" />}>
        {topLeads.length === 0 ? (
          <p className="text-sm text-neutral-500 text-center py-6">No scored leads yet. Run intelligence on leads to see rankings.</p>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-neutral-800">
                  <th className="text-left text-xs font-semibold text-neutral-400 uppercase tracking-wide py-2.5 px-3">Company</th>
                  <th className="text-left text-xs font-semibold text-neutral-400 uppercase tracking-wide py-2.5 px-3">Contact</th>
                  <th className="text-left text-xs font-semibold text-neutral-400 uppercase tracking-wide py-2.5 px-3">Industry</th>
                  <th className="text-left text-xs font-semibold text-neutral-400 uppercase tracking-wide py-2.5 px-3">Status</th>
                  <th className="text-right text-xs font-semibold text-neutral-400 uppercase tracking-wide py-2.5 px-3">Score</th>
                </tr>
              </thead>
              <tbody>
                {topLeads.map((lead) => (
                  <tr key={lead.id} className="border-b border-neutral-800/50 hover:bg-neutral-900/50 transition-colors">
                    <td className="py-3 px-3">
                      <span className="text-sm font-medium text-neutral-100">{lead.company_name}</span>
                    </td>
                    <td className="py-3 px-3">
                      <span className="text-sm text-neutral-300">{lead.contact_name}</span>
                      <span className="text-xs text-neutral-500 block">{lead.contact_title}</span>
                    </td>
                    <td className="py-3 px-3">
                      <span className="text-sm text-neutral-300">{lead.industry}</span>
                    </td>
                    <td className="py-3 px-3">
                      <StatusBadge status={lead.lead_status} />
                    </td>
                    <td className="py-3 px-3 text-right">
                      <span className="text-sm font-semibold" style={{ color: lead.score >= 80 ? '#10b981' : lead.score >= 60 ? '#f59e0b' : '#ef4444' }}>
                        {lead.score}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </Section>
    </div>
  );
}

function KpiCard({ icon, label, value, sub, color }: { icon: React.ReactNode; label: string; value: string; sub: string; color: 'primary' | 'accent' | 'warning' | 'error' }) {
  const colors: Record<string, string> = {
    primary: 'text-primary-400 bg-primary-500/10',
    accent: 'text-accent-400 bg-accent-500/10',
    warning: 'text-warning-400 bg-warning-500/10',
    error: 'text-error-400 bg-error-500/10',
  };
  return (
    <div className="card card-hover p-5">
      <div className="flex items-center justify-between mb-3">
        <span className={`w-10 h-10 rounded-lg flex items-center justify-center ${colors[color]}`}>{icon}</span>
      </div>
      <p className="text-2xl font-bold text-white">{value}</p>
      <p className="text-sm text-neutral-400 mt-0.5">{label}</p>
      {sub && <p className="text-xs text-neutral-500 mt-1">{sub}</p>}
    </div>
  );
}
