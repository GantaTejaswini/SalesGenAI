import { useEffect, useState } from 'react';
import {
  Server, Activity, Code2, Database, Clock, ArrowRight,
  CheckCircle2, XCircle, ChevronDown, ChevronUp, Copy, Check,
  Zap, FileText, Mail, Target, Layers,
} from 'lucide-react';
import { Section, Badge } from '../components/ui';
import { checkHealth } from '../lib/backend';

interface Endpoint {
  id: string;
  method: 'GET' | 'POST';
  path: string;
  title: string;
  description: string;
  icon: React.ReactNode;
  requestFields: { name: string; type: string; required: boolean; description: string }[];
  responseFields: { name: string; type: string; description: string }[];
  exampleRequest?: string;
  exampleResponse: string;
  avgTime: string;
}

const ENDPOINTS: Endpoint[] = [
  {
    id: 'health',
    method: 'GET',
    path: '/api/health',
    title: 'Health Check',
    description: 'Check if the API server is running and responsive.',
    icon: <Activity className="w-4 h-4" />,
    requestFields: [],
    responseFields: [
      { name: 'status', type: 'string', description: 'Status message confirming the server is running' },
    ],
    exampleResponse: `{
  "status": "AI-Powered Sales Forecasting Platform is running"
}`,
    avgTime: '< 1 second',
  },
  {
    id: 'analyse-lead',
    method: 'POST',
    path: '/api/analyse-lead',
    title: 'Analyse Lead',
    description: 'Analyses a company profile and returns AI-generated business insights and lead score.',
    icon: <Target className="w-4 h-4" />,
    requestFields: [
      { name: 'company_name', type: 'string', required: true, description: 'Name of the prospect company' },
      { name: 'industry', type: 'string', required: true, description: 'Industry the company operates in' },
      { name: 'contact_name', type: 'string', required: true, description: 'Name of the contact person' },
      { name: 'email', type: 'string', required: true, description: 'Contact email address' },
      { name: 'company_size', type: 'string', required: false, description: 'Number of employees e.g. "250-500"' },
      { name: 'annual_revenue', type: 'string', required: false, description: 'Revenue range e.g. "$45M - $60M"' },
      { name: 'location', type: 'string', required: false, description: 'City and country' },
      { name: 'funding_stage', type: 'string', required: false, description: 'Funding stage e.g. "Series C"' },
      { name: 'technology_stack', type: 'string', required: false, description: 'Technologies used' },
    ],
    responseFields: [
      { name: 'status', type: 'string', description: '"success" or "error"' },
      { name: 'company', type: 'string', description: 'Company name' },
      { name: 'insight.business_needs', type: 'string', description: 'AI-identified business problems' },
      { name: 'insight.opportunities', type: 'string', description: 'Where the product fits' },
      { name: 'insight.industry_analysis', type: 'string', description: 'Industry trends and challenges' },
      { name: 'insight.qualification_score', type: 'integer', description: 'Score 0-100' },
      { name: 'insight.qualification_reasoning', type: 'string', description: 'Why this score was given' },
      { name: 'score.lead_score', type: 'integer', description: 'Final lead score 0-100' },
      { name: 'score.conversion_probability', type: 'float', description: '0.0 to 1.0 (e.g. 0.85 = 85%)' },
      { name: 'score.priority_level', type: 'string', description: '"Hot", "Warm", or "Cold"' },
      { name: 'score.scoring_factors', type: 'string', description: 'Key factors behind the score' },
      { name: 'score.recommended_action', type: 'string', description: 'Next best action for sales team' },
    ],
    exampleRequest: `{
  "company_name": "TechCorp Solutions",
  "industry": "Enterprise Software",
  "contact_name": "Sarah Johnson",
  "email": "sarah@techcorp.com",
  "company_size": "250-500 employees",
  "funding_stage": "Series C",
  "location": "San Francisco, CA"
}`,
    exampleResponse: `{
  "status": "success",
  "company": "TechCorp Solutions",
  "insight": {
    "business_needs": "Scaling sales operations without linear headcount increase...",
    "opportunities": "AI-driven lead scoring for enterprise accounts...",
    "industry_analysis": "Enterprise software shifting toward AI integration...",
    "qualification_score": 88,
    "qualification_reasoning": "Series C company with high digital maturity..."
  },
  "score": {
    "lead_score": 92,
    "conversion_probability": 0.85,
    "priority_level": "Hot",
    "scoring_factors": "Strong alignment between Series C scaling...",
    "recommended_action": "Execute personalised outreach to VP of Sales..."
  }
}`,
    avgTime: '8-12 seconds',
  },
  {
    id: 'generate-email',
    method: 'POST',
    path: '/api/generate-email',
    title: 'Generate Email',
    description: 'Generates a personalised cold outreach email for a prospect.',
    icon: <Mail className="w-4 h-4" />,
    requestFields: [
      { name: 'company_name', type: 'string', required: true, description: 'Name of the prospect company' },
      { name: 'industry', type: 'string', required: true, description: 'Industry the company operates in' },
      { name: 'contact_name', type: 'string', required: true, description: 'Name of the contact person' },
      { name: 'email', type: 'string', required: true, description: 'Contact email address' },
      { name: 'company_size', type: 'string', required: false, description: 'Number of employees' },
      { name: 'funding_stage', type: 'string', required: false, description: 'Funding stage' },
      { name: 'location', type: 'string', required: false, description: 'City and country' },
      { name: 'annual_revenue', type: 'string', required: false, description: 'Revenue range' },
      { name: 'technology_stack', type: 'string', required: false, description: 'Technologies used' },
    ],
    responseFields: [
      { name: 'status', type: 'string', description: '"success" or "error"' },
      { name: 'company', type: 'string', description: 'Company name' },
      { name: 'email.subject', type: 'string', description: 'Email subject line' },
      { name: 'email.body', type: 'string', description: 'Full email body text' },
      { name: 'email.follow_up_timing', type: 'string', description: 'When to follow up if no reply' },
      { name: 'email.channel_recommendation', type: 'string', description: 'Best channel to reach this contact' },
    ],
    exampleRequest: `{
  "company_name": "TechCorp Solutions",
  "industry": "Enterprise Software",
  "contact_name": "Sarah Johnson",
  "email": "sarah@techcorp.com",
  "funding_stage": "Series C"
}`,
    exampleResponse: `{
  "status": "success",
  "company": "TechCorp Solutions",
  "email": {
    "subject": "Scaling TechCorp's sales velocity post-Series C",
    "body": "Sarah, navigating the jump to Series C at TechCorp usually brings...",
    "follow_up_timing": "3 days",
    "channel_recommendation": "LinkedIn Message with a personalised connection request"
  }
}`,
    avgTime: '12-18 seconds',
  },
  {
    id: 'analyse-meeting',
    method: 'POST',
    path: '/api/analyse-meeting',
    title: 'Analyse Meeting',
    description: 'Analyses a sales call or meeting transcript and extracts structured intelligence.',
    icon: <FileText className="w-4 h-4" />,
    requestFields: [
      { name: 'transcript', type: 'string', required: true, description: 'Raw meeting or call transcript text' },
      { name: 'company_name', type: 'string', required: true, description: 'Name of the company discussed' },
      { name: 'contact_name', type: 'string', required: true, description: 'Name of the contact in the meeting' },
    ],
    responseFields: [
      { name: 'status', type: 'string', description: '"success" or "error"' },
      { name: 'company', type: 'string', description: 'Company name' },
      { name: 'conversation.summary', type: 'string', description: '2-3 sentence meeting overview' },
      { name: 'conversation.key_discussion_points', type: 'string[]', description: 'Main topics discussed' },
      { name: 'conversation.action_items', type: 'string[]', description: 'Tasks assigned in the meeting' },
      { name: 'conversation.next_steps', type: 'string', description: 'What happens after this meeting' },
      { name: 'conversation.sentiment', type: 'string', description: '"Positive", "Neutral", or "Negative"' },
    ],
    exampleRequest: `{
  "company_name": "TechCorp Solutions",
  "contact_name": "Sarah Johnson",
  "transcript": "Sarah: We struggle with manual lead qualification. Alex: Our platform automates that completely..."
}`,
    exampleResponse: `{
  "status": "success",
  "company": "TechCorp Solutions",
  "conversation": {
    "summary": "Alex and Sarah discussed implementing an AI sales platform...",
    "key_discussion_points": [
      "Automating lead qualification to save SDR research time",
      "Implementation timeline for Q3 board meeting deadlines",
      "Budget availability within approved Q3 infrastructure upgrades"
    ],
    "action_items": [
      "Alex to send a formal proposal by Thursday",
      "Alex to include a custom ROI analysis for TechCorp"
    ],
    "next_steps": "Follow-up meeting scheduled for Tuesday to review the proposal.",
    "sentiment": "Positive"
  }
}`,
    avgTime: '5-8 seconds',
  },
  {
    id: 'full-pipeline',
    method: 'POST',
    path: '/api/full-pipeline',
    title: 'Full Pipeline',
    description: 'Runs the complete AI pipeline in one call. Combines all four engines: analysis, scoring, email generation, and conversation analysis.',
    icon: <Layers className="w-4 h-4" />,
    requestFields: [
      { name: 'company_name', type: 'string', required: true, description: 'Name of the prospect company' },
      { name: 'industry', type: 'string', required: true, description: 'Industry' },
      { name: 'contact_name', type: 'string', required: true, description: 'Contact person name' },
      { name: 'email', type: 'string', required: true, description: 'Contact email address' },
      { name: 'company_size', type: 'string', required: false, description: 'Number of employees' },
      { name: 'annual_revenue', type: 'string', required: false, description: 'Revenue range' },
      { name: 'location', type: 'string', required: false, description: 'City and country' },
      { name: 'funding_stage', type: 'string', required: false, description: 'Funding stage' },
      { name: 'technology_stack', type: 'string', required: false, description: 'Technologies used' },
      { name: 'transcript', type: 'string', required: false, description: 'Meeting transcript (if available)' },
    ],
    responseFields: [
      { name: 'status', type: 'string', description: '"success" or "error"' },
      { name: 'company', type: 'string', description: 'Company name' },
      { name: 'insight', type: 'object', description: 'Business insights (same as analyse-lead)' },
      { name: 'score', type: 'object', description: 'Lead score (same as analyse-lead)' },
      { name: 'email', type: 'object', description: 'Generated email (same as generate-email)' },
      { name: 'conversation', type: 'object|null', description: 'Meeting analysis (null if no transcript)' },
      { name: 'followup', type: 'object|null', description: 'Follow-up recommendation (null if no transcript)' },
    ],
    exampleRequest: `{
  "company_name": "TechCorp Solutions",
  "industry": "Enterprise Software",
  "contact_name": "Sarah Johnson",
  "email": "sarah@techcorp.com",
  "funding_stage": "Series C",
  "transcript": "Sarah: We struggle with manual lead qualification..."
}`,
    exampleResponse: `{
  "status": "success",
  "company": "TechCorp Solutions",
  "insight": { "business_needs": "...", "qualification_score": 88 },
  "score": { "lead_score": 92, "conversion_probability": 0.85, "priority_level": "Hot" },
  "email": { "subject": "...", "body": "...", "follow_up_timing": "3 days" },
  "conversation": { "summary": "...", "action_items": ["..."], "sentiment": "Positive" },
  "followup": { "follow_up_message": "...", "timing": "Thursday morning", "deal_risk": "Low" }
}`,
    avgTime: '20-35 seconds',
  },
];

const TECH_STACK = [
  { component: 'API Framework', technology: 'FastAPI' },
  { component: 'Server', technology: 'Uvicorn' },
  { component: 'AI Model', technology: 'Google Gemini 2.0 Flash' },
  { component: 'Data Validation', technology: 'Pydantic' },
  { component: 'Language', technology: 'Python 3.12' },
  { component: 'Database', technology: 'Supabase (PostgreSQL)' },
];

const PIPELINE_STEPS = [
  { label: 'Company Analysis', desc: 'Business needs & opportunities', icon: <Target className="w-4 h-4" /> },
  { label: 'Lead Scoring', desc: '0-100 score + conversion probability', icon: <Zap className="w-4 h-4" /> },
  { label: 'Outreach Email', desc: 'Subject, body & channel', icon: <Mail className="w-4 h-4" /> },
  { label: 'Conversation AI', desc: 'Summary & action items', icon: <FileText className="w-4 h-4" /> },
  { label: 'Follow-Up', desc: 'Timing & deal risk assessment', icon: <CheckCircle2 className="w-4 h-4" /> },
];

export function BackendView() {
  const [healthStatus, setHealthStatus] = useState<'checking' | 'online' | 'offline'>('checking');
  const [expanded, setExpanded] = useState<string | null>('analyse-lead');
  const [copied, setCopied] = useState<string | null>(null);

  useEffect(() => {
    checkHealth().then((ok) => setHealthStatus(ok ? 'online' : 'offline'));
  }, []);

  function handleCopy(id: string, text: string) {
    navigator.clipboard.writeText(text);
    setCopied(id);
    setTimeout(() => setCopied(null), 2000);
  }

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Header */}
      <div className="card p-5">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <span className="w-10 h-10 rounded-lg bg-primary-500/10 flex items-center justify-center">
              <Server className="w-5 h-5 text-primary-400" />
            </span>
            <div>
              <h2 className="text-lg font-bold text-white">Backend API</h2>
              <p className="text-sm text-neutral-400">FastAPI server powered by Google Gemini 2.0 Flash</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <div className={`flex items-center gap-2 px-3 py-1.5 rounded-full border text-xs font-medium ${
              healthStatus === 'online'
                ? 'bg-accent-500/10 border-accent-500/20 text-accent-300'
                : healthStatus === 'offline'
                ? 'bg-error-500/10 border-error-500/20 text-error-300'
                : 'bg-neutral-800 border-neutral-700 text-neutral-400'
            }`}>
              {healthStatus === 'checking' ? (
                <><div className="w-2 h-2 rounded-full bg-neutral-500 animate-pulse" /> Checking...</>
              ) : healthStatus === 'online' ? (
                <><CheckCircle2 className="w-3.5 h-3.5" /> Server Online</>
              ) : (
                <><XCircle className="w-3.5 h-3.5" /> Server Offline</>
              )}
            </div>
            <Badge variant="neutral">Base URL: 127.0.0.1:8000</Badge>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Pipeline flow + Tech stack */}
        <div className="lg:col-span-4 space-y-6">
          {/* Pipeline Flow */}
          <Section title="Pipeline Flow" icon={<Layers className="w-4 h-4" />}>
            <div className="space-y-1">
              {PIPELINE_STEPS.map((step, idx) => (
                <div key={step.label}>
                  <div className="flex items-start gap-3 p-3 bg-neutral-950 rounded-lg border border-neutral-800">
                    <span className="w-8 h-8 rounded-lg bg-primary-500/10 flex items-center justify-center text-primary-400 shrink-0">
                      {step.icon}
                    </span>
                    <div className="min-w-0 flex-1">
                      <p className="text-sm font-medium text-neutral-100">{step.label}</p>
                      <p className="text-xs text-neutral-500 mt-0.5">{step.desc}</p>
                    </div>
                    <span className="text-xs text-neutral-600 font-mono shrink-0">{idx + 1}</span>
                  </div>
                  {idx < PIPELINE_STEPS.length - 1 && (
                    <div className="flex justify-center py-1">
                      <ArrowRight className="w-4 h-4 text-neutral-700 rotate-90" />
                    </div>
                  )}
                </div>
              ))}
            </div>
          </Section>

          {/* Tech Stack */}
          <Section title="Tech Stack" icon={<Code2 className="w-4 h-4" />}>
            <div className="space-y-2">
              {TECH_STACK.map((t) => (
                <div key={t.component} className="flex items-center justify-between p-3 bg-neutral-950 rounded-lg border border-neutral-800">
                  <span className="text-sm text-neutral-400">{t.component}</span>
                  <span className="text-sm font-medium text-neutral-100">{t.technology}</span>
                </div>
              ))}
            </div>
          </Section>

          {/* Response Times */}
          <Section title="Response Times" icon={<Clock className="w-4 h-4" />}>
            <div className="space-y-2">
              {ENDPOINTS.map((e) => (
                <div key={e.id} className="flex items-center justify-between p-2.5 bg-neutral-950 rounded-lg border border-neutral-800">
                  <span className="text-xs text-neutral-400 font-mono">{e.path}</span>
                  <span className="text-xs text-accent-400 font-medium">{e.avgTime}</span>
                </div>
              ))}
            </div>
          </Section>
        </div>

        {/* Right: Endpoints */}
        <div className="lg:col-span-8 space-y-4">
          <Section title="API Endpoints" icon={<Server className="w-4 h-4" />} action={<Badge variant="primary">{ENDPOINTS.length} endpoints</Badge>}>
            <div className="space-y-3">
              {ENDPOINTS.map((ep) => {
                const isOpen = expanded === ep.id;
                return (
                  <div key={ep.id} className="bg-neutral-950 border border-neutral-800 rounded-lg overflow-hidden">
                    {/* Endpoint header */}
                    <button
                      onClick={() => setExpanded(isOpen ? null : ep.id)}
                      className="w-full flex items-center gap-3 p-4 hover:bg-neutral-900/50 transition-colors"
                    >
                      <span className={`text-xs font-bold px-2 py-1 rounded font-mono ${
                        ep.method === 'GET' ? 'bg-accent-500/15 text-accent-300' : 'bg-primary-500/15 text-primary-300'
                      }`}>
                        {ep.method}
                      </span>
                      <span className="text-sm font-mono text-neutral-200 flex-1 text-left">{ep.path}</span>
                      <span className="text-primary-400 hidden sm:block">{ep.icon}</span>
                      {isOpen ? <ChevronUp className="w-4 h-4 text-neutral-500" /> : <ChevronDown className="w-4 h-4 text-neutral-500" />}
                    </button>

                    {/* Expanded content */}
                    {isOpen && (
                      <div className="px-4 pb-4 space-y-4 animate-slide-up">
                        <p className="text-sm text-neutral-400">{ep.description}</p>

                        {/* Request fields */}
                        {ep.requestFields.length > 0 && (
                          <div>
                            <p className="text-xs font-semibold text-neutral-400 uppercase tracking-wide mb-2">Request Body</p>
                            <div className="overflow-x-auto">
                              <table className="w-full text-xs">
                                <thead>
                                  <tr className="text-neutral-500 border-b border-neutral-800">
                                    <th className="text-left py-1.5 pr-3 font-medium">Field</th>
                                    <th className="text-left py-1.5 pr-3 font-medium">Type</th>
                                    <th className="text-left py-1.5 pr-3 font-medium">Required</th>
                                    <th className="text-left py-1.5 font-medium">Description</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  {ep.requestFields.map((f) => (
                                    <tr key={f.name} className="border-b border-neutral-900">
                                      <td className="py-1.5 pr-3 font-mono text-primary-300">{f.name}</td>
                                      <td className="py-1.5 pr-3 font-mono text-neutral-400">{f.type}</td>
                                      <td className="py-1.5 pr-3">
                                        {f.required ? <span className="text-error-400 text-xs">Yes</span> : <span className="text-neutral-600 text-xs">No</span>}
                                      </td>
                                      <td className="py-1.5 text-neutral-400">{f.description}</td>
                                    </tr>
                                  ))}
                                </tbody>
                              </table>
                            </div>
                          </div>
                        )}

                        {/* Response fields */}
                        <div>
                          <p className="text-xs font-semibold text-neutral-400 uppercase tracking-wide mb-2">Response Fields</p>
                          <div className="overflow-x-auto">
                            <table className="w-full text-xs">
                              <thead>
                                <tr className="text-neutral-500 border-b border-neutral-800">
                                  <th className="text-left py-1.5 pr-3 font-medium">Field</th>
                                  <th className="text-left py-1.5 pr-3 font-medium">Type</th>
                                  <th className="text-left py-1.5 font-medium">Description</th>
                                </tr>
                              </thead>
                              <tbody>
                                {ep.responseFields.map((f) => (
                                  <tr key={f.name} className="border-b border-neutral-900">
                                    <td className="py-1.5 pr-3 font-mono text-accent-300">{f.name}</td>
                                    <td className="py-1.5 pr-3 font-mono text-neutral-400">{f.type}</td>
                                    <td className="py-1.5 text-neutral-400">{f.description}</td>
                                  </tr>
                                ))}
                              </tbody>
                            </table>
                          </div>
                        </div>

                        {/* Example request */}
                        {ep.exampleRequest && (
                          <div>
                            <div className="flex items-center justify-between mb-2">
                              <p className="text-xs font-semibold text-neutral-400 uppercase tracking-wide">Example Request</p>
                              <button onClick={() => handleCopy(`${ep.id}-req`, ep.exampleRequest!)} className="btn-ghost text-xs">
                                {copied === `${ep.id}-req` ? <Check className="w-3 h-3 text-accent-400" /> : <Copy className="w-3 h-3" />}
                              </button>
                            </div>
                            <pre className="bg-neutral-900 border border-neutral-800 rounded-lg p-3 text-xs text-neutral-300 font-mono overflow-x-auto leading-relaxed">{ep.exampleRequest}</pre>
                          </div>
                        )}

                        {/* Example response */}
                        <div>
                          <div className="flex items-center justify-between mb-2">
                            <p className="text-xs font-semibold text-neutral-400 uppercase tracking-wide">Example Response</p>
                            <button onClick={() => handleCopy(`${ep.id}-res`, ep.exampleResponse)} className="btn-ghost text-xs">
                              {copied === `${ep.id}-res` ? <Check className="w-3 h-3 text-accent-400" /> : <Copy className="w-3 h-3" />}
                            </button>
                          </div>
                          <pre className="bg-neutral-900 border border-neutral-800 rounded-lg p-3 text-xs text-neutral-300 font-mono overflow-x-auto leading-relaxed">{ep.exampleResponse}</pre>
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </Section>

          {/* Error handling */}
          <Section title="Error Handling" icon={<XCircle className="w-4 h-4" />}>
            <div className="space-y-3">
              <p className="text-sm text-neutral-400">All endpoints return a <code className="text-primary-300 font-mono">500</code> status code with error details if something fails.</p>
              <div className="overflow-x-auto">
                <table className="w-full text-xs">
                  <thead>
                    <tr className="text-neutral-500 border-b border-neutral-800">
                      <th className="text-left py-1.5 pr-3 font-medium">Code</th>
                      <th className="text-left py-1.5 pr-3 font-medium">Reason</th>
                      <th className="text-left py-1.5 font-medium">Fix</th>
                    </tr>
                  </thead>
                  <tbody>
                    <tr className="border-b border-neutral-900">
                      <td className="py-1.5 pr-3 font-mono text-error-400">500</td>
                      <td className="py-1.5 pr-3 text-neutral-400">Gemini API busy</td>
                      <td className="py-1.5 text-neutral-400">Retry after 30 seconds</td>
                    </tr>
                    <tr className="border-b border-neutral-900">
                      <td className="py-1.5 pr-3 font-mono text-error-400">422</td>
                      <td className="py-1.5 pr-3 text-neutral-400">Missing required field</td>
                      <td className="py-1.5 text-neutral-400">Check request body has all required fields</td>
                    </tr>
                    <tr className="border-b border-neutral-900">
                      <td className="py-1.5 pr-3 font-mono text-error-400">500</td>
                      <td className="py-1.5 pr-3 text-neutral-400">API key invalid</td>
                      <td className="py-1.5 text-neutral-400">Check GEMINI_API_KEY in .env file</td>
                    </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </Section>
        </div>
      </div>
    </div>
  );
}
